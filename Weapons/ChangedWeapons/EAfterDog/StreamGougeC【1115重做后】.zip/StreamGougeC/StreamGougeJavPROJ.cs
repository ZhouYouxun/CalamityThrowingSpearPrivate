﻿using CalamityMod;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using CalamityMod.Buffs.DamageOverTime;
using CalamityMod.Graphics.Metaballs;
using CalamityMod.Particles;
using Microsoft.Xna.Framework.Graphics;
using Terraria.Graphics.Shaders;
using CalamityMod.Graphics.Primitives;
using Terraria.Audio;
using CalamityMod.Projectiles.Melee;

namespace CalamityThrowingSpear.Weapons.ChangedWeapons.EAfterDog.StreamGougeC
{
    public class StreamGougeJavPROJ : ModProjectile, ILocalizedModType
    {
        public override string Texture => "CalamityThrowingSpear/Weapons/ChangedWeapons/EAfterDog/StreamGougeC/StreamGougeJav";
        public new string LocalizationCategory => "Projectiles.ChangedWeapons.EAfterDog";
        private static Color ShaderColorOne = Color.Purple;      // 紫色
        private static Color ShaderColorTwo = Color.Gray;        // 灰色
        private static Color ShaderEndColor = Color.MediumPurple;// 中紫色

        public override void SetStaticDefaults()
        {
            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 48;
            ProjectileID.Sets.TrailingMode[Projectile.type] = 2;
        }

        public override bool PreDraw(ref Color lightColor)
        {
            // 保留现有的拖尾效果
            CalamityUtils.DrawAfterimagesCentered(Projectile, ProjectileID.Sets.TrailingMode[Projectile.type], lightColor, 1);

            // 启用拖尾着色效果
            GameShaders.Misc["CalamityMod:TrailStreak"].SetShaderTexture(ModContent.Request<Texture2D>("CalamityMod/ExtraTextures/Trails/FabstaffStreak"));

            // 渲染带有紫色渐变效果的光学尾迹
            Vector2 overallOffset = Projectile.Size * 0.5f;
            overallOffset += Projectile.velocity * 1.4f;
            int numPoints = 76;

            PrimitiveRenderer.RenderTrail(Projectile.oldPos, new(PrimitiveWidthFunction, PrimitiveColorFunction, (_) => overallOffset, shader: GameShaders.Misc["CalamityMod:TrailStreak"]), numPoints);

            // 绘制弹幕本体
            Texture2D texture = Terraria.GameContent.TextureAssets.Projectile[Projectile.type].Value; // 获取弹幕的纹理
            Vector2 drawOrigin = new Vector2(texture.Width / 2, texture.Height / 2); // 计算纹理中心

            // 使用 Projectile.Center 作为绘制位置，确保弹幕在正确位置绘制
            //Main.EntitySpriteDraw(
            //    texture,
            //    Projectile.Center - Main.screenPosition,  // 修正偏移量，确保弹幕在正确位置
            //    null,
            //    lightColor,
            //    Projectile.rotation,  // 使用弹幕的旋转角度
            //    drawOrigin,  // 纹理的中心作为旋转中心
            //    Projectile.scale,  // 弹幕的缩放
            //    SpriteEffects.None,
            //    0);

            return false; // 返回 false，因为我们已经手动绘制了本体
        }


        private float PrimitiveWidthFunction(float completionRatio)
        {
            return MathHelper.Lerp(36f, 76f, completionRatio); // 拖尾宽度函数
        }

        private Color PrimitiveColorFunction(float completionRatio)
        {
            // 使用紫色、灰色和中紫色生成渐变效果
            float colorLerpFactor = 0.6f;
            float cosArgument = completionRatio * 2.7f - Main.GlobalTimeWrappedHourly * 5.3f;
            float startingInterpolant = (float)Math.Cos(cosArgument) * 0.5f + 0.5f;
            Color startingColor = Color.Lerp(ShaderColorOne, ShaderColorTwo, startingInterpolant * colorLerpFactor);
            return Color.Lerp(startingColor, ShaderEndColor, MathHelper.SmoothStep(0f, 1f, completionRatio));
        }

        public override void SetDefaults()
        {
            Projectile.width = Projectile.height = 32;
            Projectile.friendly = true;
            Projectile.hostile = false;
            Projectile.DamageType = DamageClass.Melee;
            Projectile.penetrate = -1;
            Projectile.timeLeft = 360;
            Projectile.light = 0.5f;
            Projectile.ignoreWater = true;
            Projectile.tileCollide = false;
            Projectile.extraUpdates = 2; // 额外更新次数
            Projectile.usesLocalNPCImmunity = true; // 弹幕使用本地无敌帧
            Projectile.localNPCHitCooldown = 10; // 无敌帧冷却时间为14帧
        }

        public override void AI()
        {
            // 保持弹幕旋转
            Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver4;

            // 发出紫色光芒
            Lighting.AddLight(Projectile.Center, Color.Purple.ToVector3() * 0.55f);

            // 每帧加速
            Projectile.velocity *= 1.011f;

            // 每帧留下简单的紫色粒子特效
            Dust.NewDustPerfect(Projectile.Center, DustID.PurpleTorch, Vector2.Zero).noGravity = true;

            // 增加额外的粒子效果
            AddExtraDustEffects();
        }

        private void AddExtraDustEffects()
        {
            // 特效 1：FireworkFountain_Pink
            CreateDustCircle(Projectile.Center, DustID.FireworkFountain_Pink, Color.Purple, 10f, 0.5f, 0.75f);

            // 特效 2：FireworkFountain_Blue
            CreateDustCircle(Projectile.Center, DustID.FireworkFountain_Blue, Color.Violet, 20f, 0.5f, 0.75f);

            // 特效 3：Electric
            CreateDustCircle(Projectile.Center, DustID.Electric, Color.Purple, 15f, 0.5f, 0.75f);
        }

        private void CreateDustCircle(Vector2 center, int dustType, Color color, float radius, float minScale, float maxScale)
        {
            int numDust = 8; // 每次生成的粒子数量
            for (int i = 0; i < numDust; i++)
            {
                float angle = MathHelper.TwoPi / numDust * i;
                Vector2 offset = new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle)) * radius;
                Dust dust = Dust.NewDustPerfect(center + offset, dustType, Vector2.Zero, 0, color);
                dust.noGravity = true;
                dust.scale = Main.rand.NextFloat(minScale, maxScale);
                dust.velocity = offset.SafeNormalize(Vector2.Zero) * Main.rand.NextFloat(2f, 4f);
            }
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            // 播放音效
            SoundEngine.PlaySound(SoundID.Item74, target.Center);

            // 寻找新的目标
            NPC closestNPC = Main.npc
                .Where(npc => npc.active && !npc.friendly && npc.life > 0 && npc.whoAmI != target.whoAmI)
                .Where(npc => Vector2.Distance(npc.Center, Projectile.Center) > 15 * 16 && Vector2.Distance(npc.Center, Projectile.Center) < 150 * 16)
                .OrderBy(npc => Vector2.Distance(npc.Center, Projectile.Center))
                .FirstOrDefault();

            if (closestNPC != null)
            {
                Vector2 direction = closestNPC.Center - Projectile.Center;
                Projectile.velocity = Vector2.Normalize(direction) * Projectile.velocity.Length();
            }

            // 在面朝方向生成新的弹幕
            Vector2 spawnPosition = Projectile.Center + Projectile.velocity.SafeNormalize(Vector2.Zero) * (3 * 16);
            Vector2 incomingVelocity = -Projectile.velocity.SafeNormalize(Vector2.Zero) * Projectile.velocity.Length();
            Projectile.NewProjectile(Projectile.GetSource_FromThis(), spawnPosition, incomingVelocity, ModContent.ProjectileType<StreamGougePortal>(), Projectile.damage, Projectile.knockBack, Projectile.owner);

            // 命中后生成银河系特效
            CreateGalaxyEffect(target.Center);
        }

        private void CreateGalaxyEffect(Vector2 center)
        {
            // 生成银河系悬臂
            int armCount = 4;
            int particlesPerArm = 50;
            float armRotation = MathHelper.TwoPi / armCount;

            for (int arm = 0; arm < armCount; arm++)
            {
                float angleOffset = arm * armRotation;

                for (int i = 0; i < particlesPerArm; i++)
                {
                    float progress = i / (float)particlesPerArm;
                    float spiralRadius = progress * 100f;
                    float particleAngle = angleOffset + progress * MathHelper.TwoPi;

                    Vector2 spawnPosition = center + new Vector2((float)Math.Cos(particleAngle), (float)Math.Sin(particleAngle)) * spiralRadius;
                    Vector2 velocity = Vector2.Normalize(spawnPosition - center) * Main.rand.NextFloat(2f, 5f);

                    StreamGougeMetaball.SpawnParticle(spawnPosition, velocity, Main.rand.NextFloat(20f, 40f));
                }
            }

            //// 在命中点生成两个同心圆的 ImpactParticle
            //for (int circle = 0; circle < 2; circle++)
            //{
            //    float radius = (circle + 1) * 30f;
            //    int impactParticleCount = 12;
            //    for (int i = 0; i < impactParticleCount; i++)
            //    {
            //        float angle = MathHelper.TwoPi / impactParticleCount * i;
            //        Vector2 position = center + new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle)) * radius;
            //        ImpactParticle impactParticle = new ImpactParticle(position, 0.1f, 20, 0.5f, Color.Cyan);
            //        GeneralParticleHandler.SpawnParticle(impactParticle);
            //    }
            //}

            ImpactParticle impactParticle = new ImpactParticle(center, 0.1f, 20, 0.5f, Color.Cyan);
            GeneralParticleHandler.SpawnParticle(impactParticle);
        }

        public override void OnKill(int timeLeft)
        {
            // 生成超级爆炸冲击波
            Particle largePulse = new DirectionalPulseRing(Projectile.Center, Vector2.Zero, Color.Purple, new Vector2(5f, 5f), 20f, 0.3f, 6f, 30);
            GeneralParticleHandler.SpawnParticle(largePulse);

            // 生成超级银河系特效
            CreateGalaxyEffect(Projectile.Center, true);

            // 释放伤害倍率为1.0的 StreamGougeJavEXP 弹幕
            Projectile.NewProjectile(Projectile.GetSource_FromThis(), Projectile.Center, Vector2.Zero, ModContent.ProjectileType<StreamGougeJavEXP>(), Projectile.damage, Projectile.knockBack, Projectile.owner);
        }

        private void CreateGalaxyEffect(Vector2 center, bool enhanced)
        {
            int armCount = enhanced ? 8 : 4;
            int particlesPerArm = enhanced ? 100 : 50;
            float armRotation = MathHelper.TwoPi / armCount;

            for (int arm = 0; arm < armCount; arm++)
            {
                float angleOffset = arm * armRotation;

                for (int i = 0; i < particlesPerArm; i++)
                {
                    float progress = i / (float)particlesPerArm;
                    float spiralRadius = progress * (enhanced ? 200f : 100f);
                    float particleAngle = angleOffset + progress * MathHelper.TwoPi;

                    Vector2 spawnPosition = center + new Vector2((float)Math.Cos(particleAngle), (float)Math.Sin(particleAngle)) * spiralRadius;
                    Vector2 velocity = Vector2.Normalize(spawnPosition - center) * Main.rand.NextFloat(2f, 5f);

                    StreamGougeMetaball.SpawnParticle(spawnPosition, velocity, Main.rand.NextFloat(20f, enhanced ? 80f : 40f));
                }
            }

            if (enhanced)
            {
                // 增强模式下额外增加粒子效果
                for (int i = 0; i < 50; i++)
                {
                    Vector2 randomOffset = Main.rand.NextVector2Circular(300f, 300f);
                    StreamGougeMetaball.SpawnParticle(center + randomOffset, -randomOffset * 0.1f, Main.rand.NextFloat(40f, 100f));
                }
            }
        }



    }
}