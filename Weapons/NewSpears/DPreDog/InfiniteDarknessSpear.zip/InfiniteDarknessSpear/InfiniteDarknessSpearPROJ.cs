﻿using CalamityMod.Particles;
using CalamityMod;
using CalamityThrowingSpear.Global;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;

namespace CalamityThrowingSpear.Weapons.NewSpears.DPreDog.InfiniteDarknessSpear
{
    internal class InfiniteDarknessSpearPROJ : ModProjectile, ILocalizedModType
    {
        public new string LocalizationCategory => "Projectile.DPreDog";
        public override string Texture => "CalamityThrowingSpear/Weapons/NewSpears/DPreDog/InfiniteDarknessSpear/InfiniteDarknessSpear";

        public override void SetStaticDefaults()
        {
            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 1;
            ProjectileID.Sets.TrailingMode[Projectile.type] = 1;
        }
        public override bool PreDraw(ref Color lightColor)
        {
            // 画残影效果
            CalamityUtils.DrawAfterimagesCentered(Projectile, ProjectileID.Sets.TrailingMode[Projectile.type], lightColor, 1);
            return false;
        }
        public override void SetDefaults()
        {
            // 设置弹幕的基础属性
            Projectile.width = 11; // 弹幕宽度
            Projectile.height = 24; // 弹幕高度
            Projectile.friendly = true; // 对敌人有效
            Projectile.DamageType = DamageClass.Melee; // 远程伤害类型
            Projectile.penetrate = -1; // 穿透力为1，击中一个敌人就消失
            Projectile.timeLeft = 360000; // 弹幕存在时间为600帧
            Projectile.usesLocalNPCImmunity = true; // 弹幕使用本地无敌帧
            Projectile.localNPCHitCooldown = 1; // 无敌帧冷却时间为14帧
            Projectile.ignoreWater = true; // 弹幕不受水影响
            Projectile.arrow = true;
            Projectile.extraUpdates = 1;
        }


        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {

        }

        public override void AI()
        {
            Player player = Main.player[Projectile.owner];

            // 计算枪尾位置（始终固定在玩家中心）
            Vector2 gunTailPosition = Projectile.Center - Projectile.velocity.SafeNormalize(Vector2.Zero) * 16f * 3f + Main.rand.NextVector2Circular(5f, 5f);
            gunTailPosition = player.Center;

            // 计算基础朝向（从玩家中心指向鼠标）
            Vector2 baseDirection = (Main.MouseWorld - gunTailPosition).SafeNormalize(Vector2.UnitX);

            // 计算枪体实际位置（从枪尾朝向鼠标移动 3 × 16）
            Projectile.Center = gunTailPosition + baseDirection * (3 * 16);

            // 计算旋转抖动（±10°）
            float baseRotation = baseDirection.ToRotation();
            float randomShake = MathHelper.ToRadians(Main.rand.NextFloat(-10f, 10f));
            Projectile.rotation = baseRotation + randomShake + MathHelper.PiOver4;

            // 计算枪头位置
            //Vector2 gunHeadPosition = gunTailPosition - baseDirection * (3 * 16);
            Vector2 gunHeadPosition = Projectile.Center + Projectile.velocity.SafeNormalize(Vector2.Zero) * 16f * 3f + Main.rand.NextVector2Circular(5f, 5f);
            // 在枪头释放黑暗粒子（Dust 175, 191）
            for (int i = 0; i < 3; i++) // 每次最多释放 3 个粒子
            {
                if (Main.rand.NextBool(2)) // 50% 概率
                {
                    Dust dust = Dust.NewDustDirect(gunHeadPosition + Main.rand.NextVector2Circular(8f, 8f), 2, 2, Main.rand.NextBool() ? 175 : 191,
                                                   baseDirection.X * Main.rand.NextFloat(1f, 3f),
                                                   baseDirection.Y * Main.rand.NextFloat(1f, 3f),
                                                   100,
                                                   Color.Black, 3f); // 放大 2 倍
                    dust.noGravity = true;
                }
            }

            // 释放黑色/暗紫色的 SparkParticle，每次释放 1~3 个，偏移更大
            int sparkCount = Main.rand.Next(1, 4); // 1 ~ 3 个
            for (int i = 0; i < sparkCount; i++)
            {
                Color[] darkColors = { Color.Black, new Color(75, 0, 130), new Color(48, 25, 52) }; // 黑色、深紫、暗蓝
                Color sparkColor = darkColors[Main.rand.Next(darkColors.Length)];
                float scaleBoost = MathHelper.Clamp(Projectile.ai[0] * 0.01f, 0f, 4f); // 放大 2 倍
                float sparkScale = 2.4f + scaleBoost; // 放大 2 倍

                // 更加剧烈的偏移
                Vector2 sparkOffset = Main.rand.NextVector2Circular(12f, 12f);
                SparkParticle spark = new SparkParticle(gunHeadPosition + sparkOffset,
                                                        baseDirection * Main.rand.NextFloat(2f, 4f), // 让特效方向与枪体一致
                                                        false,
                                                        14, // 延长寿命
                                                        sparkScale,
                                                        sparkColor);
                GeneralParticleHandler.SpawnParticle(spark);
            }

            // 让投射物对齐到玩家
            player.heldProj = Projectile.whoAmI;

            ManipulatePlayerArmPositions();

            // 检测松手
            if (!Owner.channel)
                Projectile.Kill();
        }
        public void ManipulatePlayerArmPositions()
        {
            Owner.ChangeDir((Main.MouseWorld.X > Owner.Center.X) ? 1 : -1); // 只允许向前伸展
            Owner.heldProj = Projectile.whoAmI;

            // 计算基础的手臂方向（始终指向鼠标）
            float baseArmRotation = (Main.MouseWorld - Owner.Center).ToRotation() - MathHelper.PiOver2;

            // 添加抖动效果
            float armShake = MathHelper.ToRadians(Main.rand.NextFloat(-8f, 8f)); // 在 ±8° 内随机抖动
            float finalArmRotation = baseArmRotation + armShake;

            // 应用抖动后的手臂方向
            Owner.SetCompositeArmFront(true, Player.CompositeArmStretchAmount.Full, finalArmRotation);
            Owner.SetCompositeArmBack(true, Player.CompositeArmStretchAmount.Full, finalArmRotation);
        }




        public Player Owner => Main.player[Projectile.owner];




    }
}