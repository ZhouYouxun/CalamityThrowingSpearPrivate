﻿using CalamityMod.Buffs.DamageOverTime;
using CalamityMod.Buffs.StatDebuffs;
using CalamityMod.Particles;
using CalamityMod;
using CalamityThrowingSpear.Weapons.NewWeapons.EAfterDog.AuricJav;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using Terraria.ModLoader.IO;

namespace CalamityThrowingSpear.Weapons.NewWeapons.EAfterDog.PrimordialState
{
    internal class PrimordialStatePROJ : ModProjectile, ILocalizedModType
    {
        public override string Texture => "CalamityThrowingSpear/Weapons/NewWeapons/EAfterDog/PrimordialState/PrimordialState";

        public new string LocalizationCategory => "Projectiles.NewWeapons.EAfterDog";
        public override void SetStaticDefaults()
        {
            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 5;
            ProjectileID.Sets.TrailingMode[Projectile.type] = 2;
        }
        private int phase = 1;
        private int phaseTimer = 0;
        public override bool PreDraw(ref Color lightColor)
        {
            CalamityUtils.DrawAfterimagesCentered(Projectile, ProjectileID.Sets.TrailingMode[Projectile.type], lightColor, 1);
            return false;
        }

        public override void SetDefaults()
        {
            Projectile.width = Projectile.height = 32;
            Projectile.friendly = true;
            Projectile.hostile = false;
            Projectile.DamageType = DamageClass.Melee;
            Projectile.penetrate = -1; // 允许1次伤害
            Projectile.timeLeft = 600;
            Projectile.light = 0.5f;
            Projectile.ignoreWater = true;
            Projectile.tileCollide = true; // 允许与方块碰撞
            Projectile.extraUpdates = 2; // 额外更新次数
            Projectile.usesLocalNPCImmunity = true; // 弹幕使用本地无敌帧
            Projectile.localNPCHitCooldown = 14; // 无敌帧冷却时间为14帧
        }

        public override void AI()
        {
            // Lighting - 添加深橙色光源，光照强度为 0.55
            Lighting.AddLight(Projectile.Center, Color.Black.ToVector3() * 0.55f);

            // 根据阶段执行对应逻辑
            switch (phase)
            {
                case 1:
                    PerformPhaseOne();
                    break;
                case 2:
                    PerformPhaseTwo();
                    break;
                case 3:
                    PerformPhaseThree();
                    break;
                case 4:
                    PerformPhaseFour(); // 新增的停留旋转阶段
                    break;
                case 5:
                    PerformPhaseFive(); // 原来的冲刺阶段
                    break;
            }
        }

        private void PerformPhaseOne() // 第一阶段：弱追踪
        {
            // 保持弹幕旋转（对于倾斜走向的弹幕而言）
            Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver4;

            // 前30帧不追踪，之后开始追踪敌人
            if (Projectile.ai[1] > 24)
            {
                // 寻找最近的敌人并调整方向
                NPC target = Projectile.Center.ClosestNPCAt(5000);
                if (target != null)
                {
                    Vector2 direction = (target.Center - Projectile.Center).SafeNormalize(Vector2.Zero);
                    float desiredRotation = direction.ToRotation();
                    float currentRotation = Projectile.velocity.ToRotation();
                    float rotationDifference = MathHelper.WrapAngle(desiredRotation - currentRotation);
                    float rotationAmount = MathHelper.ToRadians(Main.rand.Next(1, 10));

                    if (Math.Abs(rotationDifference) < rotationAmount)
                    {
                        rotationAmount = rotationDifference;
                    }

                    Projectile.velocity = Projectile.velocity.RotatedBy(rotationAmount);
                }
            }
            else
            {
                Projectile.ai[1]++;
            }                     

            // 四螺旋粒子特效
            for (int i = 0; i < 4; i++)
            {
                float rotation = (Main.GameUpdateCount * 0.1f + MathHelper.PiOver2 * i) % MathHelper.TwoPi;
                Vector2 offset = new Vector2((float)Math.Cos(rotation), (float)Math.Sin(rotation)) * 24;
                Dust dust = Dust.NewDustPerfect(Projectile.Center + offset, DustID.Torch, Main.rand.NextVector2Circular(2f, 2f), 150, Color.Gray, Main.rand.NextFloat(0.8f, 1.5f));
                dust.noGravity = true;
            }
        }

        private void PerformPhaseTwo() // 第2阶段：快速减速
        {
            // 保持弹幕旋转（对于倾斜走向的弹幕而言）
            Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver4;

            Projectile.velocity *= 0.98f;
            if (++phaseTimer >= 20)
            {
                phase = 3;
                phaseTimer = 0;
                CreateSlashProjectile();
            }
        }

        private void PerformPhaseThree() // 第3阶段：持续追踪
        {
            NPC target = Projectile.Center.ClosestNPCAt(2400);
            if (target != null)
            {
                Vector2 direction = (target.Center - Projectile.Center).SafeNormalize(Vector2.Zero);
                Projectile.velocity = Vector2.Lerp(Projectile.velocity, direction * 28f, 0.08f);
            }
            Projectile.rotation += 0.45f;
            // 每隔 20 帧，增加随机冲刺的效果
            if (phaseTimer % 20 == 0)
            {
                float randomAngle = Main.rand.NextFloat(MathHelper.TwoPi); // 随机生成一个角度
                Vector2 randomDash = new Vector2((float)Math.Cos(randomAngle), (float)Math.Sin(randomAngle)) * 10f; // 冲刺速度大小
                Projectile.velocity += randomDash; // 在当前速度基础上增加随机冲刺速度
            }
            if (++phaseTimer >= 150)
            {
                phase = 4;
                phaseTimer = 0;
                RandomDash();
            }
        }
        private void PerformPhaseFour() // 第4阶段：原地停留一段时间
        {
            // 弹幕保持旋转
            Projectile.rotation += 0.45f;

            // 停留在原地，不移动
            Projectile.velocity = Vector2.Zero;

            // 计时器增加
            if (++phaseTimer >= 15)
            {
                // 切换到第 5 阶段（冲刺）
                phase = 5;
                phaseTimer = 0;
                RandomDash();
            }
        }
        private void PerformPhaseFive() // 第5阶段：冲出去
        {
            Projectile.rotation += 0.45f;
            if (++phaseTimer >= 30)
            {
                Projectile.Kill(); // 最后消除自己
            }
        }

        private void CreateSlashProjectile()
        {
            int slashID = Projectile.NewProjectile(Projectile.GetSource_FromThis(), Projectile.Center, Vector2.Zero, ModContent.ProjectileType<PrimordialStateSlash>(), Projectile.damage * 0, 0f, Projectile.owner, Projectile.whoAmI);
            Projectile.localAI[0] = slashID + 1;
        }

        private void RandomDash()
        {
            float randomAngle = Main.rand.NextFloat(MathHelper.TwoPi);
            Projectile.velocity = new Vector2((float)Math.Cos(randomAngle), (float)Math.Sin(randomAngle)) * 30f;
        }

        public override void OnKill(int timeLeft)
        {
            int slashID = (int)(Projectile.localAI[0] - 1);
            if (Main.projectile.IndexInRange(slashID) && Main.projectile[slashID].type == ModContent.ProjectileType<PrimordialStateSlash>())
            {
                Main.projectile[slashID].Kill();
            }
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            // 切换到第二阶段
            if (phase == 1)
            {
                phase = 2;
                phaseTimer = 0; // 重置阶段计时器

                SoundStyle sound = new SoundStyle("CalamityMod/Sounds/Item/AuricBulletHit")
                {
                    Volume = 0.4f // 将音量设置为 x%
                };
                SoundEngine.PlaySound(sound, Projectile.position);
            }

            SoundEngine.PlaySound(SoundID.Item89, Projectile.position);

            
            // 电火花特效逻辑
            for (int i = 0; i < 6; i++)
            {
                int sparkLifetime = Main.rand.Next(22, 36);
                float sparkScale = Main.rand.NextFloat(0.8f, 1f);
                Color sparkColor = Color.Lerp(Color.Black, Color.Gray, Main.rand.NextFloat(0.5f, 1f)); // 黑色和灰色渐变

                if (Main.rand.NextBool(10))
                    sparkScale *= 2f;

                // 随机方向的速度
                Vector2 sparkVelocity = Main.rand.NextVector2Circular(25f, 25f); // 生成一个随机方向的速度向量，速度范围为 [-25, 25]
                SparkParticle spark = new SparkParticle(Projectile.Center, sparkVelocity, true, sparkLifetime, sparkScale, sparkColor);
                GeneralParticleHandler.SpawnParticle(spark);
            }


            target.AddBuff(ModContent.BuffType<BurningBlood>(), 300);
            target.AddBuff(ModContent.BuffType<BrainRot>(), 300);   
            target.AddBuff(ModContent.BuffType<HolyFlames>(), 300); 
            target.AddBuff(31, 300);
        }
    }
}
