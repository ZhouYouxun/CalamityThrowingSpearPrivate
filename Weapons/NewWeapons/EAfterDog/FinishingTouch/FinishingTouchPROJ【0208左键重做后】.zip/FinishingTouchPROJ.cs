﻿using CalamityMod;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using CalamityMod.Particles;
using CalamityMod.Projectiles.Typeless;
using Microsoft.Xna.Framework.Graphics;
using Terraria.DataStructures;
using Terraria.GameContent;
using CalamityMod.NPCs.Bumblebirb;
using CalamityMod.Sounds;
using CalamityThrowingSpear.Weapons.ChangedWeapons.EAfterDog.DragonRageC;
using Terraria.Audio;
using CalamityMod.Buffs.DamageOverTime;

namespace CalamityThrowingSpear.Weapons.NewWeapons.EAfterDog.FinishingTouch
{
    internal class FinishingTouchPROJ : ModProjectile, ILocalizedModType
    {
        public override string Texture => "CalamityThrowingSpear/Weapons/NewWeapons/EAfterDog/FinishingTouch/FinishingTouch";
        public new string LocalizationCategory => "Projectiles.NewWeapons.EAfterDog";
        public override void SetStaticDefaults()
        {
            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 15;
            ProjectileID.Sets.TrailingMode[Projectile.type] = 1;
            Main.projFrames[Projectile.type] = 4; // 设置投射物的帧数为 4
        }

        public override bool PreDraw(ref Color lightColor) // 确保贴图的中心点为绘制的中心点
        {
            SpriteBatch spriteBatch = Main.spriteBatch;
            Texture2D texture = TextureAssets.Projectile[Projectile.type].Value;

            // 计算当前动画帧
            int frameCount = 4; // 总共 4 帧
            int frameHeight = texture.Height / frameCount; // 每帧的高度
            int currentFrame = (int)(Main.GameUpdateCount / 6 % frameCount); // 每 6 帧切换一次，总共 4 帧
            Rectangle sourceRectangle = new Rectangle(0, currentFrame * frameHeight, texture.Width, frameHeight);

            // 设置绘制的原点和位置
            Vector2 drawOrigin = new Vector2(texture.Width / 2, frameHeight / 2); // 每帧的高度作为原点
            Vector2 drawPosition = Projectile.Center - Main.screenPosition + new Vector2(0f, Projectile.gfxOffY);

            // 绘制当前帧
            spriteBatch.Draw(texture, drawPosition, sourceRectangle, lightColor, Projectile.rotation, drawOrigin, Projectile.scale, SpriteEffects.None, 0f);

            return false;
        }

        public override void OnSpawn(IEntitySource source)
        {
            //for (float angle = -15f; angle <= 15f; angle += 1f)
            //{
            //    Vector2 particleDirectionLeft = Projectile.velocity.RotatedBy(MathHelper.ToRadians(angle));
            //    Vector2 particleDirectionRight = Projectile.velocity.RotatedBy(MathHelper.ToRadians(-angle));

            //    // 左右方向各释放粒子
            //    Particle particleLeft = new SparkParticle(Projectile.Center, particleDirectionLeft * 3f, false, 40, 1.5f, Color.OrangeRed);
            //    Particle particleRight = new SparkParticle(Projectile.Center, particleDirectionRight * 3f, false, 40, 1.5f, Color.OrangeRed);

            //    GeneralParticleHandler.SpawnParticle(particleLeft);
            //    GeneralParticleHandler.SpawnParticle(particleRight);
            //}
        }
        public override void SetDefaults()
        {
            Projectile.width = Projectile.height = 32;
            Projectile.friendly = true;
            Projectile.hostile = false;
            Projectile.DamageType = DamageClass.Melee;
            Projectile.penetrate = 1; // 允许6次伤害
            Projectile.timeLeft = 120;
            Projectile.light = 0.5f;
            Projectile.ignoreWater = true;
            Projectile.tileCollide = true; // 允许与方块碰撞
            Projectile.extraUpdates = 1; // 额外更新次数
            Projectile.usesLocalNPCImmunity = true; // 弹幕使用本地无敌帧
            Projectile.localNPCHitCooldown = 14; // 无敌帧冷却时间为1帧
        }
        private int phase = 0; // 记录当前的阶段
        private int phaseTimer = 0; // 记录当前阶段的时间
        private bool laserSpawned = false; // 确保激光只生成一次
        public override void AI()
        {
            Player player = Main.player[Projectile.owner];

            // 每 6 帧切换一次帧
            if (++Projectile.frameCounter >= 6)
            {
                Projectile.frameCounter = 0; // 重置帧计数器
                Projectile.frame++; // 切换到下一帧
                if (Projectile.frame >= Main.projFrames[Projectile.type])
                {
                    Projectile.frame = 0; // 如果超过了最大帧数，回到第一帧
                }
            }

            {
                // 定义一个偏移距离，用来增加粒子之间的间隔
                float offsetDistance = 20f;

                // 计算特效生成位置，始终在弹幕的正左方和正右方（基于弹幕当前方向）
                Vector2 leftOffset = Projectile.velocity.RotatedBy(MathHelper.PiOver2).SafeNormalize(Vector2.Zero) * offsetDistance;
                Vector2 rightOffset = Projectile.velocity.RotatedBy(-MathHelper.PiOver2).SafeNormalize(Vector2.Zero) * offsetDistance;

                Vector2 leftTrailPos = Projectile.Center + leftOffset;
                Vector2 rightTrailPos = Projectile.Center + rightOffset;

                // 生成橙红色粒子特效
                Color orangeRed = Color.OrangeRed;
                Particle leftTrail = new SparkParticle(leftTrailPos, Projectile.velocity * 0.2f, false, 60, 1f, orangeRed);
                Particle rightTrail = new SparkParticle(rightTrailPos, Projectile.velocity * 0.2f, false, 60, 1f, orangeRed);
                GeneralParticleHandler.SpawnParticle(leftTrail);
                GeneralParticleHandler.SpawnParticle(rightTrail);

                // 生成左右漂移的轻型烟雾特效
                int dustCount = 1; // 每次生成的烟雾数量
                float radians = MathHelper.TwoPi / dustCount;
                Vector2 smokePoint = Vector2.Normalize(new Vector2(-1f, -1f));
                for (int i = 0; i < dustCount; i++)
                {
                    Vector2 dustVelocity = smokePoint.RotatedBy(radians * i).RotatedByRandom(0.5f) * Main.rand.NextFloat(1f, 2.6f);
                    Color smokeColor = Color.White;
                    Particle smoke = new HeavySmokeParticle(Projectile.Center, dustVelocity * Main.rand.NextFloat(1f, 2.6f), Color.Orange, 18, Main.rand.NextFloat(0.9f, 1.6f), 0.35f, Main.rand.NextFloat(-1, 1), true);
                    GeneralParticleHandler.SpawnParticle(smoke);
                }
            }



            // **第一阶段：减速 + 旋转至正上方**
            if (phase == 0)
            {
                Projectile.velocity *= 0.93f; // 逐步减速

                // 目标旋转角度（屏幕正上方）
                float targetRotation = -MathHelper.PiOver2; // 绝对正上方方向
                Projectile.rotation = MathHelper.Lerp(Projectile.rotation, targetRotation, 0.1f); // 平滑转向
                Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver4;

                Projectile.timeLeft = 120; //  不断的重置弹幕的剩余时间
                Projectile.penetrate = -1;
                // **阶段结束条件**
                if (++phaseTimer >= 40 * 2)
                {
                    phase++;
                    phaseTimer = 0;
                }
            }

            // **第二阶段（21~55 帧）：加速前冲**
            else if (phase == 1)
            {
                if (Projectile.velocity.Length() < 15f)
                {
                    // 固定朝正上方方向加速
                    Projectile.velocity += new Vector2(0, -1f) * 0.35f; // Y 方向加速
                }
                else
                {
                    // 限制速度不超过 17f
                    Projectile.velocity = new Vector2(0, -15f);
                }

                // 确保弹幕旋转方向正确
                Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver4;

                Projectile.timeLeft = 120; //  不断的重置弹幕的剩余时间
                Projectile.penetrate = -1;

                // **阶段结束条件**
                if (++phaseTimer >= 35 * 2)
                {
                    phase++;
                    phaseTimer = 0;
                    Projectile.timeLeft = 150; // 最后一阶段的时间
                    SoundEngine.PlaySound(SoundID.Item68, Projectile.Center);
                    Projectile.penetrate = 1;
                }
            }

            // **第三阶段（56~115 帧）：慢速追踪 + 释放激光**
            else if (phase == 2)
            {
                // 找到最近的敌人
                NPC target = Projectile.Center.ClosestNPCAt(1500f); // 搜索范围 1500 像素
                if (target != null)
                {
                    // 计算朝向目标的方向向量
                    float maxTurnSpeed = 0.05f; // 限制转向速度
                    Vector2 directionToTarget = (target.Center - Projectile.Center).SafeNormalize(Vector2.Zero);
                    float targetRotation = directionToTarget.ToRotation();

                    // 平滑转向目标
                    Projectile.rotation = MathHelper.Lerp(Projectile.rotation, targetRotation, maxTurnSpeed);
                    Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver4;
                    Projectile.velocity = directionToTarget * 13f; // 固定追踪速度
                }
                else
                {
                    // 如果没有目标，则保持当前方向的速度
                    Projectile.velocity *= 0.998f; // 渐渐减速
                    Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver4;
                }

                if (!laserSpawned)
                {
                    if (Main.netMode != NetmodeID.MultiplayerClient)
                    {
                        // **寻找最近的敌人**
                        float initialRotation = Projectile.rotation; // 默认朝向
                        if (target != null)
                        {
                            initialRotation = (target.Center - Projectile.Center).ToRotation();
                        }

                        // **创建激光**
                        int laser = Projectile.NewProjectile(Projectile.GetSource_FromThis(),
                            Projectile.Center,
                            initialRotation.ToRotationVector2(), // **让激光一开始就朝向目标**
                            ModContent.ProjectileType<FinishingTouchLazer>(),
                            Projectile.damage,
                            0f,
                            Projectile.owner,
                            Projectile.whoAmI // 绑定当前弹幕 ID
                        );

                        if (laser.WithinBounds(Main.maxProjectiles))
                        {
                            Main.projectile[laser].ai[0] = Projectile.whoAmI; // **绑定激光**
                            Main.projectile[laser].rotation = initialRotation; // **确保激光一开始的方向是正确的**
                        }
                    }
                    laserSpawned = true;
                }

            }


            // **发光效果**
            Lighting.AddLight(Projectile.Center, Color.Orange.ToVector3() * 0.55f);







        }


        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            target.AddBuff(ModContent.BuffType<Dragonfire>(), 300); // 龙焰

            int slashCount = 2; // 生成2到3个斩击特效
            for (int i = 0; i < slashCount; i++)
            {
                // 随机生成方向
                Vector2 randomDirection = Vector2.UnitX.RotatedByRandom(MathHelper.TwoPi);
                int slashID = ModContent.ProjectileType<OrangeSLASH>();
                Projectile.NewProjectile(Projectile.GetSource_FromThis(), target.Center, randomDirection, slashID, (int)(Projectile.damage * 2.5f), Projectile.knockBack, Projectile.owner);
            }

            // 给予5秒钟的创造胜利
            int buffDuration = 5 * 60; // 5 秒钟，单位为帧（每秒 60 帧）
            target.AddBuff(ModContent.BuffType<CreateVictoryPEBuff>(), buffDuration);

            SoundEngine.PlaySound(CommonCalamitySounds.SwiftSliceSound with { Volume = CommonCalamitySounds.SwiftSliceSound.Volume * 0.5f }, Projectile.Center);
        }
     
        public override void OnKill(int timeLeft)
        {
            //ReleaseFireballs();
            //ReleaseLinearParticles();
        }

        private void ReleaseFireballs()
        {
            int fireballType = ModContent.ProjectileType<FinishingTouchBALL>();
            float baseAngle = MathHelper.TwoPi / 16; // 每个火球的角度

            for (int i = 0; i < 16; i++)
            {
                float randomAngle = Main.rand.NextFloat(0, MathHelper.TwoPi);

                // 计算每个弹幕的方向向量
                Vector2 direction = new Vector2((float)Math.Cos(randomAngle), (float)Math.Sin(randomAngle));

                // 设定弹幕的速度和伤害
                Vector2 fireballVelocity = baseAngle.ToRotationVector2().RotatedBy(baseAngle * i) * 10f; // 初始速度为原来的8.5倍Main.rand.NextFloat(0.75f, 2f)
                Projectile.NewProjectile(Projectile.GetSource_FromThis(), Projectile.Center, fireballVelocity, fireballType, (int)(Projectile.damage * 0.25f), Projectile.knockBack, Projectile.owner);
            }
        }


        private void ReleaseLinearParticles()
        {
            float baseAngle = MathHelper.TwoPi / 24; // 20个粒子的扩散角度

            for (int i = 0; i < 24; i++)
            {
                Vector2 trailPos = Projectile.Center;
                Vector2 trailVelocity = baseAngle.ToRotationVector2().RotatedBy(baseAngle * i) * 0.2f;
                Color trailColor = Color.OrangeRed;
                float trailScale = 1.5f;

                Particle trail = new SparkParticle(trailPos, trailVelocity, false, 60, trailScale, trailColor);
                GeneralParticleHandler.SpawnParticle(trail);
            }
        }
    }
}

