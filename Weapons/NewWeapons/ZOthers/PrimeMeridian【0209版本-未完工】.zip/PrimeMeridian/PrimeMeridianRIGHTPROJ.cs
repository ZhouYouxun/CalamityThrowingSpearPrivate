﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.Graphics.Shaders;
using CalamityMod.Graphics.Primitives;
using CalamityMod;
using CalamityMod.Items.Weapons.Melee;
using CalamityMod.Projectiles.Melee;
using Terraria.DataStructures;

namespace CalamityThrowingSpear.Weapons.NewWeapons.EAfterDog.PrimeMeridian
{
    public class PrimeMeridianRIGHTPROJ : ModProjectile
    {
        private const int NumAnimationFrames = 4;
        private const int AnimationFrameTime = 12;
        private const float TentacleRange = 140f;
        private const float TentacleCooldown = 25f;
        public bool StartFading = false;
        public ref float Time => ref Projectile.ai[1];


        public override void SetStaticDefaults()
        {
            Main.projFrames[Projectile.type] = NumAnimationFrames;
            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 35;
            ProjectileID.Sets.TrailingMode[Projectile.type] = 2;
        }
        public override void SetDefaults()
        {
            Projectile.height = 24;
            Projectile.width = 24;
            Projectile.DamageType = DamageClass.Melee;
            Projectile.timeLeft = 600;
            Projectile.friendly = true;
            Projectile.tileCollide = false;
            Projectile.ignoreWater = true;
            Projectile.alpha = 80;

            Projectile.penetrate = 2;
            Projectile.usesLocalNPCImmunity = true;
            Projectile.localNPCHitCooldown = 4;
            Projectile.extraUpdates = 1;
        }
        private int homingStartTime;  // 追踪开始时间（30~60）
        private float homingRange;    // 追踪范围（1800~2500）
        private float homingStrength; // 追踪强度（12~18）
        public override void OnSpawn(IEntitySource source)
        {
            homingStartTime = Main.rand.Next(30, 61);  // 30~60 帧后开始追踪
            homingRange = Main.rand.NextFloat(1800f, 2500f); // 1800~2500 像素的追踪范围
            homingStrength = Main.rand.NextFloat(12f, 18f); // 追踪强度 12~18
                                                            }

        public override void AI()
        {
            Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver2;
            DrawOffsetX = 1;
            DrawOriginOffsetY = 4;

            // Update animation
            Projectile.frameCounter++;
            if (Projectile.frameCounter > AnimationFrameTime)
            {
                Projectile.frame++;
                Projectile.frameCounter = 0;
            }
            if (Projectile.frame >= NumAnimationFrames)
                Projectile.frame = 0;

            // Produce light
            Lighting.AddLight(Projectile.Center, 0.9f, 0.9f, 1.0f);

            // Continuously trail dust
            int trailDust = 1;
            for (int i = 0; i < trailDust; ++i)
            {
                int dustID = Main.rand.NextBool(8) ? 66 : 143;

                int idx = Dust.NewDust(Projectile.position - Projectile.velocity, Projectile.width, Projectile.height, dustID);
                Main.dust[idx].noGravity = true;
                Main.dust[idx].velocity += Projectile.velocity * 0.8f;
            }

            // If tentacle is currently on cooldown, reduce the cooldown.
            if (Projectile.ai[0] > 0f)
                Projectile.ai[0] -= 1f;

            // **前 homingStartTime 帧不追踪，之后开始追踪敌人**
            if (Projectile.ai[1] > homingStartTime)
            {
                NPC target = Projectile.Center.ClosestNPCAt(homingRange); // 查找范围内最近的敌人
                if (target != null)
                {
                    Vector2 direction = (target.Center - Projectile.Center).SafeNormalize(Vector2.Zero);
                    Projectile.velocity = Vector2.Lerp(Projectile.velocity, direction * homingStrength, 0.08f); // 追踪强度为随机值
                }
            }
            else
            {
                Projectile.ai[1]++;
            }


            // Fade-out.
            if (StartFading)
                Projectile.alpha += Nadir.FadeoutSpeed;

            Time++;
        }

        private void HomingAI()
        {
            // Find the closest NPC within range.
            int targetIdx = -1;
            float maxHomingRange = 400f;
            bool hasHomingTarget = false;
            foreach (NPC npc in Main.ActiveNPCs)
            {
                // Won't home in through walls and won't chase invulnerable targets.
                if (npc.CanBeChasedBy(Projectile, false) && Collision.CanHit(Projectile.Center, 1, 1, npc.Center, 1, 1))
                {
                    float dist = (Projectile.Center - npc.Center).Length();
                    if (dist < maxHomingRange)
                    {
                        targetIdx = npc.whoAmI;
                        maxHomingRange = dist;
                        hasHomingTarget = true;
                    }
                }
            }

            // Home in on said closest NPC.
            if (hasHomingTarget)
            {
                NPC target = Main.npc[targetIdx];
                Vector2 homingVector = (target.Center - Projectile.Center).SafeNormalize(Vector2.Zero) * Nadir.ProjShootSpeed;
                float homingRatio = 35f;
                Projectile.velocity = (Projectile.velocity * homingRatio + homingVector) / (homingRatio + 1f);

                // If the target is close enough and tentacle is off cooldown, summon one.
                // maxHomingRange doubles as the distance to the target.
                if (Projectile.ai[0] <= 0f && maxHomingRange <= TentacleRange)
                {
                    Vector2 projVel = (target.Center - Projectile.Center).SafeNormalize(Vector2.Zero);
                    projVel *= 6f;
                    SpawnTentacle(projVel);
                    Projectile.ai[0] = TentacleCooldown;
                }
            }
        }



        private float PrimitiveWidthFunction(float completionRatio)
        {
            float width = 10f;
            float minWidth = 0.03f;
            float maxWidth = width;

            if (completionRatio <= 0.3f) // 让拖尾前段变细
                width = MathHelper.Lerp(minWidth, maxWidth, Utils.GetLerpValue(0f, 0.3f, completionRatio, true));

            return width;
        }

        private Color PrimitiveColorFunction(float completionRatio)
        {
            float timeFactor = Main.GlobalTimeWrappedHourly * 4.0f;
            float flicker = (float)Math.Sin(completionRatio * 6f + timeFactor) * 0.5f + 0.5f;

            Color startColor = Color.Lerp(Color.Black, Color.Gray, flicker);
            return Color.Lerp(startColor, Color.Transparent, MathHelper.SmoothStep(0f, 1f, completionRatio));
        }




        public override bool PreDraw(ref Color lightColor)
        {
            Texture2D texture = Terraria.GameContent.TextureAssets.Projectile[Projectile.type].Value;
            int framing = texture.Height / Main.projFrames[Projectile.type]; // 获取单帧高度
            int y6 = framing * Projectile.frame; // 计算当前帧的 Y 坐标

            // **仅绘制本体，不绘制拖尾和着色器**
            Main.spriteBatch.Draw(
                texture,
                Projectile.Center - Main.screenPosition + new Vector2(0f, Projectile.gfxOffY),
                new Rectangle(0, y6, texture.Width, framing),
                Projectile.GetAlpha(lightColor),
                Projectile.rotation,
                new Vector2(texture.Width / 2f, framing / 2f),
                Projectile.scale,
                SpriteEffects.None,
                0
            );

            // 绑定 `BasicPrimitiveShader`
            GameShaders.Misc["CalamityMod:PrimitiveDrawer"].SetShaderTexture(
                ModContent.Request<Texture2D>("CalamityMod/ExtraTextures/Trails/FabstaffStreak")
            );

            Vector2 overallOffset = Projectile.Size * 0.5f;
            overallOffset += Projectile.velocity * 1.2f; // 稍微调整偏移

            int numPoints = 30; // 拖尾采样点数量

            // 调用 `PrimitiveRenderer.RenderTrail()` 渲染拖尾
            PrimitiveRenderer.RenderTrail(
                Projectile.oldPos,
                new(
                    PrimitiveWidthFunction,  // 计算拖尾宽度
                    PrimitiveColorFunction,  // 计算拖尾颜色
                    (_) => overallOffset,    // 位置偏移
                    shader: GameShaders.Misc["CalamityMod:PrimitiveDrawer"] // 使用 `BasicPrimitiveShader`
                ),
                numPoints
            );
            return false;
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            // Rapidly screech to a halt upon touching an enemy and disable homing.
            Projectile.velocity *= 0.4f;
            Projectile.ai[1] = 1f;

            // Start fading after hitting the target.
            StartFading = true;

            // Explode into dust (as if being shredded apart on contact)
            int onHitDust = Main.rand.Next(6, 11);
            for (int i = 0; i < onHitDust; ++i)
            {
                int dustID = Main.rand.NextBool() ? 198 : 199;
                int idx = Dust.NewDust(Projectile.position, Projectile.width, Projectile.height, dustID, 0f, 0f);

                Main.dust[idx].noGravity = true;
                float speed = Main.rand.NextFloat(1.4f, 2.6f);
                Main.dust[idx].velocity *= speed;
                float scale = Main.rand.NextFloat(1.0f, 1.8f);
                Main.dust[idx].scale = scale;
            }
        }

        public override void OnKill(int timeLeft)
        {
            // Create a burst of dust
            int killDust = Main.rand.Next(30, 41);
            for (int i = 0; i < killDust; ++i)
            {
                int dustID = Main.rand.NextBool() ? 198 : 199;
                int idx = Dust.NewDust(Projectile.position, Projectile.width, Projectile.height, dustID, 0f, 0f);

                Main.dust[idx].noGravity = true;
                float speed = Main.rand.NextFloat(2.0f, 3.1f);
                Main.dust[idx].velocity *= speed;
                float scale = Main.rand.NextFloat(1.0f, 1.8f);
                Main.dust[idx].scale = scale;
            }

            // Spawn three tentacles pointing in random directions
            for (int i = 0; i < 3; ++i)
            {
                Vector2 projVel = Vector2.One.RotatedByRandom(MathHelper.TwoPi);
                projVel *= 4f;
                SpawnTentacle(projVel);
            }
        }

        private void SpawnTentacle(Vector2 tentacleVelocity)
        {
            int damage = Projectile.damage;
            float kb = Projectile.knockBack;

            // Randomize tentacle behavior variables
            float ai0 = Main.rand.NextFloat(0.01f, 0.08f);
            ai0 *= Main.rand.NextBool() ? -1f : 1f;
            float ai1 = Main.rand.NextFloat(0.01f, 0.08f);
            ai1 *= Main.rand.NextBool() ? -1f : 1f;

            if (Projectile.owner == Main.myPlayer)
                Projectile.NewProjectile(Projectile.GetSource_FromThis(), Projectile.Center, tentacleVelocity, ModContent.ProjectileType<VoidTentacle>(), damage, kb, Projectile.owner, ai0, ai1);
        }


        public override bool? CanDamage() => Time >= 15f; // 初始的时候不会造成伤害，直到15为止

    }
}
