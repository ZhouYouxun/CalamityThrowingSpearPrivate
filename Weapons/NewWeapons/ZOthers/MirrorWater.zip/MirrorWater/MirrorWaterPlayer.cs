﻿using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using CalamityThrowingSpear.Projectiles;
using CalamityMod.Particles;
using CalamityMod;
using System;

namespace CalamityThrowingSpear.Weapons.NewWeapons.ZOthers.MirrorWater
{
    public class MirrorWaterPlayer : ModPlayer
    {
        public bool hasMirrorWater = false;
        private int chargeCounter = 0;
        public bool isChargingReady = false; // 让GProj知道是否可以标记弹幕

        public override void ResetEffects()
        {
            hasMirrorWater = false;
        }

        public override void PreUpdate()
        {
            if (!hasMirrorWater)
            {
                chargeCounter = 0;
                isChargingReady = false;
                return;
            }

            // 如果已经充能完毕（正在等待下一次弹幕释放），不再继续计时
            if (isChargingReady)
                return;

            // 检测玩家是否静止
            if (Player.velocity.LengthSquared() < 0.01f) // 近乎静止
            {
                chargeCounter++;

                // 生成吸收能量的 Dust 效果
                if (chargeCounter % 10 == 0) // 每 10 帧一次
                {
                    for (int i = 0; i < 4; i++)
                    {
                        int dustType = Main.rand.NextBool() ? 240 : 175; // 黑色 Dust
                        int whiteDustType = Main.rand.NextBool() ? 91 : 63; // 白色 Dust

                        Vector2 dustPos = Player.Center + new Vector2(Main.rand.NextFloat(-20f, 20f), Main.rand.NextFloat(-20f, 20f));
                        Vector2 velocity = (Player.Center - dustPos).SafeNormalize(Vector2.Zero) * Main.rand.NextFloat(2f, 5f);

                        Dust.NewDustPerfect(dustPos, dustType, velocity, 100, Color.Black, 1.5f);
                        Dust.NewDustPerfect(dustPos, whiteDustType, velocity, 100, Color.White, 1.5f);
                    }
                }

                // 达到 300 帧（5 秒）
                if (chargeCounter == 300 && !isChargingReady)
                {
                    // **触发“太极特效”**
                    Particle blastRing = new CustomPulse(
                        Player.Center,
                        Vector2.Zero,
                        Color.White,
                        "CalamityThrowingSpear/texture/YingYang", // 把这个改成你的纹理路径
                        Vector2.One * 0.33f,
                        Main.rand.NextFloat(-10f, 10f),
                        0.17f,
                        0.43f,
                        30
                    );
                    GeneralParticleHandler.SpawnParticle(blastRing);

                    // **触发屏幕震动**
                    float shakePower = 5f; // 震动强度
                    Main.LocalPlayer.Calamity().GeneralScreenShakePower = Math.Max(Main.LocalPlayer.Calamity().GeneralScreenShakePower, shakePower);

                    // **通知 GProj 监听下一发弹幕**
                    isChargingReady = true;
                }
            }
            else
            {
                chargeCounter = 0;
                isChargingReady = false;
            }
        }

        public void NotifyChargeComplete()
        {
            isChargingReady = false; // 让GProj通知后关闭状态
            chargeCounter = 0; // 重新开始计时，确保可以重新进入充能状态
        }
    }
}
