﻿using Terraria;
using Terraria.ModLoader;
using CalamityThrowingSpear.Weapons.NewWeapons.ZOthers.MirrorWater;
using Terraria.ID;
using Microsoft.Xna.Framework;
using CalamityMod.Particles;
using Terraria.DataStructures;

namespace CalamityThrowingSpear.Projectiles
{
    public class MirrorWaterGlobalProjectile : GlobalProjectile
    {
        public override bool InstancePerEntity => true;
        public bool isChargedProjectile = false; // 该弹幕是否获得了10倍伤害状态


        // 如果你希望被开启的只有一发弹幕触发这个效果，那么启用这一段
        public override void OnSpawn(Projectile projectile, IEntitySource source)
        {
            Player owner = Main.player[projectile.owner];
            if (owner != null)
            {
                MirrorWaterPlayer modPlayer = owner.GetModPlayer<MirrorWaterPlayer>();

                // 监听玩家是否开启了充能状态
                if (modPlayer.isChargingReady)
                {
                    isChargedProjectile = true; // 赋予该弹幕特殊标记
                    modPlayer.NotifyChargeComplete();
                }
            }
        }


        // 如果你希望这发弹幕和他额外制造的弹幕全部享有这次超级暴击效果，那么启用这一段
        //public override void OnSpawn(Projectile projectile, IEntitySource source)
        //{
        //    Player owner = Main.player[projectile.owner];
        //    if (owner != null)
        //    {
        //        MirrorWaterPlayer modPlayer = owner.GetModPlayer<MirrorWaterPlayer>();

        //        // 监听玩家是否开启了充能状态
        //        if (modPlayer.isChargingReady)
        //        {
        //            isChargedProjectile = true; // 赋予该弹幕特殊标记
        //            modPlayer.isChargingReady = false; // 立刻关闭充能状态，防止后续弹幕触发
        //        }
        //        else if (source is EntitySource_Parent parentSource)
        //        {
        //            // 检查是否由一个已标记的弹幕生成
        //            Projectile parentProj = Main.projectile[parentSource.Entity.whoAmI];
        //            MirrorWaterGlobalProjectile parentGlobal = parentProj.GetGlobalProjectile<MirrorWaterGlobalProjectile>();

        //            if (parentGlobal != null && parentGlobal.isChargedProjectile)
        //            {
        //                isChargedProjectile = true; // 让子弹幕也获得 10 倍伤害
        //            }
        //        }
        //    }
        //}


        public override void ModifyHitNPC(Projectile projectile, NPC target, ref NPC.HitModifiers modifiers)
        {
            Player owner = Main.player[projectile.owner];
            if (owner != null)
            {
                MirrorWaterPlayer modPlayer = owner.GetModPlayer<MirrorWaterPlayer>();

                // 判断该弹幕是否是标记的弹幕，且它本身是暴击弹幕
                if (isChargedProjectile && projectile.CritChance > 0) // 只有被标记的弹幕才生效
                {
                    // 造成 10 倍伤害
                    modifiers.SourceDamage *= 10f;
                    modifiers.SetCrit(); // 强制暴击

                    // 释放太极特效
                    Particle blastRing = new CustomPulse(
                        projectile.Center,
                        Vector2.Zero,
                        Color.White,
                        "CalamityThrowingSpear/texture/YingYang", // 把这个改成你的纹理路径
                        Vector2.One * 0.33f,
                        Main.rand.NextFloat(-10f, 10f),
                        0.17f,
                        0.43f,
                        30
                    );
                    GeneralParticleHandler.SpawnParticle(blastRing);

                    // **通知 Player 重新开始充能**
                    modPlayer.NotifyChargeComplete();
                }
            }
        }
    }
}
