﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria.Audio;
using Terraria.DataStructures;
using Terraria.Graphics.Shaders;
using CalamityMod;

namespace CalamityThrowingSpear.Weapons.NewWeapons.ZOthers.GlobalStorm
{
    public class GlobalStormCloud : ModProjectile
    {
        public override void SetDefaults()
        {
            Projectile.width = 40;
            Projectile.height = 30;
            Projectile.tileCollide = false;
            Projectile.ignoreWater = true;
            Projectile.friendly = true;
            Projectile.penetrate = -1;
            Projectile.timeLeft = 999999;
        }

        Texture2D flashTex = ModContent.Request<Texture2D>("CalamityMod/Projectiles/Summon/AquasScepterCloudFlash").Value;
        Texture2D glowTex = ModContent.Request<Texture2D>("CalamityMod/Projectiles/Summon/AquasScepterCloudGlowmask").Value;

        public int DrawFlashTimer = 0;
        public override void AI()
        {
            Player owner = Main.player[Projectile.owner];
            if (!owner.active || owner.HeldItem.type != ModContent.ItemType<GlobalStorm>())
            {
                Projectile.Kill();
                return;
            }
            Projectile.Center = owner.Center + new Vector2(0, -12 * 16);

            // **每 45 帧发射一轮子弹**
            if (Projectile.ai[0]++ % 45 == 0)
            {
                if (owner.HasAmmo(owner.HeldItem))
                {
                    bool dontConsumeAmmo = Main.rand.NextBool();
                    owner.PickAmmo(owner.HeldItem, out int ammoProjectile, out float shootSpeed, out int damage, out float knockback, out _, dontConsumeAmmo);

                    // **每轮 X 发子弹**
                    int bulletCount = Main.rand.Next(25, 45);

                    for (int i = 0; i < bulletCount; i++)
                    {
                        // **在 8×16 区域随机选取一个点**
                        float offsetX = Main.rand.NextFloat(-4 * 16f, 4 * 16f);
                        Vector2 spawnPosition = Projectile.Center + new Vector2(offsetX, 0);

                        // **子弹向正下方一点随机发射**
                        Vector2 velocity = Vector2.UnitY.RotatedBy(MathHelper.ToRadians(Main.rand.NextFloat(-15f, 15f))) * shootSpeed;

                        // **发射子弹**
                        int projID = Projectile.NewProjectile(
                            Projectile.GetSource_FromThis(),
                            spawnPosition,
                            velocity,
                            ammoProjectile, // **使用玩家的弹药**
                            damage,
                            knockback,
                            Projectile.owner
                        );

                        // **修改子弹的 `timeLeft` 和 `tileCollide`**
                        if (projID >= 0 && projID < Main.maxProjectiles)
                        {
                            Projectile proj = Main.projectile[projID];
                            proj.timeLeft = 120; // **固定存活时间为 120**
                            proj.tileCollide = true; // **子弹可撞墙**
                        }
                    }

                    // **播放闪电音效**
                    SoundEngine.PlaySound(new SoundStyle("CalamityMod/Sounds/Item/LightningAura"), Projectile.Center);
                    DrawFlashTimer = 27; // **触发闪光效果**
                }
            }
        }

        public override bool? CanDamage()
        {
            return false;
        }
        public override void PostDraw(Color lightColor)
        {
            Main.spriteBatch.End();
            Main.spriteBatch.Begin(SpriteSortMode.Immediate, BlendState.AlphaBlend, SamplerState.LinearClamp, DepthStencilState.Default, RasterizerState.CullNone, null, Main.GameViewMatrix.ZoomMatrix);

            MiscShaderData msd = GameShaders.Misc["CalamityMod:WavyOpacity"];
            msd.SetShaderTexture(ModContent.Request<Texture2D>("CalamityMod/ExtraTextures/GreyscaleGradients/BlobbyNoise"), 1);
            msd.UseOpacity(0.7f);

            Vector2 glowOrigin = new Vector2(glowTex.Width / 2, glowTex.Height / 2); // 计算居中偏移
            Vector2 glowPos = Projectile.Center - Main.screenPosition + new Vector2(0f, Projectile.gfxOffY);

            DrawData dd = new()
            {
                texture = glowTex,
                position = glowPos,
                sourceRect = glowTex.Bounds,
            };
            msd.Apply(dd);
            Main.EntitySpriteDraw(glowTex, glowPos, null, dd.color, 0f, glowOrigin, 1f, SpriteEffects.None);

            Main.spriteBatch.End();
            Main.spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, Main.DefaultSamplerState, DepthStencilState.None, Main.Rasterizer, null, Main.GameViewMatrix.TransformationMatrix);

            if (DrawFlashTimer > 0)
            {
                float opacity = 1f - ((27 - DrawFlashTimer) / 27f);
                Vector2 flashOrigin = new Vector2(flashTex.Width / 2, flashTex.Height / 2); // 计算居中偏移
                Vector2 drawPosition = Projectile.Center - Main.screenPosition + new Vector2(0f, Projectile.gfxOffY);

                Main.EntitySpriteDraw(flashTex, drawPosition, null, Color.White * opacity, 0f, flashOrigin, 1f, SpriteEffects.None);
                DrawFlashTimer--;
            }
        }
        public override bool PreDraw(ref Color lightColor)
        {
            return false;                    
        }
    }
}
