﻿using CalamityMod.Buffs.DamageOverTime;
using CalamityMod.Particles;
using CalamityMod;
using CalamityThrowingSpear.Weapons.ChangedWeapons.CPreMoodLord.TenebreusTidesC;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using Terraria.DataStructures;
using CalamityMod.Projectiles.Summon;

namespace CalamityThrowingSpear.Weapons.NewWeapons.ZOthers.GlobalStorm
{
    internal class GlobalStormRightHoldOut : ModProjectile
    {
        public override string Texture => "CalamityThrowingSpear/Weapons/NewWeapons/ZOthers/GlobalStorm/GlobalStorm";

        public enum BehaviorState
        {
            Aim,
            //Dash
        }

        public BehaviorState CurrentState
        {
            get => (BehaviorState)Projectile.ai[0];
            set => Projectile.ai[0] = (int)value;
        }

        public override void SetStaticDefaults()
        {
            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 1;
            ProjectileID.Sets.TrailingMode[Projectile.type] = 2;
        }

        public override bool PreDraw(ref Color lightColor)
        {
            Texture2D texture = Terraria.GameContent.TextureAssets.Projectile[Projectile.type].Value;
            Rectangle frame = texture.Frame(1, Main.projFrames[Projectile.type], 0, Projectile.frame);
            Vector2 origin = frame.Size() * 0.5f;
            Vector2 drawPosition = Projectile.Center - Main.screenPosition;
            SpriteEffects direction = Projectile.spriteDirection == 1 ? SpriteEffects.None : SpriteEffects.FlipHorizontally;

            Main.EntitySpriteDraw(texture, drawPosition, frame, Projectile.GetAlpha(lightColor), Projectile.rotation, origin, Projectile.scale, direction, 0);
            
            return false;
        }

        public override void SetDefaults()
        {
            Projectile.width = Projectile.height = 32;
            Projectile.friendly = true;
            Projectile.hostile = false;
            Projectile.DamageType = DamageClass.Ranged;
            Projectile.penetrate = -1;
            Projectile.timeLeft = 1500;
            Projectile.extraUpdates = 1;
            Projectile.usesLocalNPCImmunity = true;
            Projectile.localNPCHitCooldown = 14;
        }
        public Player Owner => Main.player[Projectile.owner];

        public override void AI()
        {
            switch (CurrentState)
            {
                case BehaviorState.Aim:
                    DoBehavior_Aim();
                    break;
                    //case BehaviorState.Dash:
                    //    DoBehavior_Dash();
                    //    break;
            }
        }
        //public override void OnSpawn(IEntitySource source)
        //{
        //    if (Main.myPlayer == Projectile.owner)
        //    {
        //        Vector2 spawnPosition = Projectile.Center + Projectile.velocity.SafeNormalize(Vector2.Zero) * 16f * 3f + Main.rand.NextVector2Circular(5f, 5f);
        //        Projectile.NewProjectile(Projectile.GetSource_FromThis(), spawnPosition, Vector2.Zero, ModContent.ProjectileType<GlobalStormRightMagic>(), 0, 0, Projectile.owner);
        //    }
        //}

        private void DoBehavior_Aim()
        {
            Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver4;
            Projectile.timeLeft = 300;
            Projectile.penetrate = -1;
            Projectile.tileCollide = false;


            // 使投射物与玩家保持一致并瞄准鼠标位置
            if (Main.myPlayer == Projectile.owner)
            {
                Vector2 aimDirection = Owner.SafeDirectionTo(Main.MouseWorld);
                Projectile.velocity = Vector2.Lerp(Projectile.velocity, aimDirection, 0.1f);
            }

            // 对齐到玩家中心
            Projectile.Center = Owner.Center + Projectile.velocity.SafeNormalize(Vector2.Zero) * (Projectile.width / 1);
            Owner.heldProj = Projectile.whoAmI;

            // **计算枪头位置**
            Vector2 smokePosition = Projectile.Center + Projectile.velocity.SafeNormalize(Vector2.Zero) * 16f * 4.5f + Main.rand.NextVector2Circular(5f, 5f);

            // **计算烟雾的喷射方向（与子弹方向一致）**
            Vector2 smokeVelocity = Projectile.velocity.SafeNormalize(Vector2.Zero) * Main.rand.NextFloat(3f, 7f);

            // **创建烟雾粒子**
            Particle smoke = new HeavySmokeParticle(
                smokePosition,
                smokeVelocity, // **改成朝向弹幕的方向**
                Color.Lerp(Color.DarkBlue, Color.CadetBlue, 0.5f),
                Main.rand.Next(30, 60),
                Main.rand.NextFloat(0.25f, 0.5f),
                1.0f,
                MathHelper.ToRadians(Main.rand.NextFloat(-5f, 5f)),
                true
            );

            // **生成烟雾粒子**
            GeneralParticleHandler.SpawnParticle(smoke);


            if (lightBallCounter < 18 && Projectile.ai[1] % 25 == 0) // 每 Z 帧生成一个光球
            {
                GenerateLightBall();
            }

            // **光球充能完成后，每 X 帧射击一次**
            if (lightBallCounter == 18)
            {
                shootingTimer++;
                if (shootingTimer % 14 == 0)
                {
                    FireProjectile(); // **发射子弹**
                }
            }

            Projectile.ai[1]++;

            // 检测松手
            Player player = Main.player[Projectile.owner];
            if (!player.Calamity().mouseRight)
            {
                Projectile.netUpdate = true;
                Projectile.Kill();
                SoundEngine.PlaySound(SoundID.Item79, Projectile.position);
            }
        }

        private void GenerateLightBall()
        {
            if (lightBallCounter >= 18) return; // 最多生成 X 个

            // **计算枪头位置**
            Vector2 gunHeadPosition = Projectile.Center + Projectile.velocity.SafeNormalize(Vector2.Zero) * 16f * 4.5f + Main.rand.NextVector2Circular(5f, 5f);

            // **生成光球**
            Vector2 randomDirection = Main.rand.NextVector2Unit(); // **生成随机方向**
            int proj = Projectile.NewProjectile(
                Owner.GetSource_FromThis(),
                gunHeadPosition,
                randomDirection * 7f, // 初始速度固定为
                ModContent.ProjectileType<GlobalStormLightBall>(),
                Projectile.damage, // 伤害设为主弹幕的 1.0 倍
                0,
                Owner.whoAmI
            );

            SoundEngine.PlaySound(SoundID.Item9, gunHeadPosition);
            lightBallCounter++;

            if (lightBallCounter == 18)
            {
                // **触发特殊特效（屏幕闪烁 + 震动）**
                Main.LocalPlayer.Calamity().GeneralScreenShakePower = 5f;
                for (int i = 0; i < 30; i++)
                {
                    Vector2 dustPos = Owner.Center + Main.rand.NextVector2Circular(8 * 16, 8 * 16);
                    Dust d = Dust.NewDustPerfect(dustPos, DustID.Electric, Vector2.Zero, 100, Color.Cyan, 2f);
                    d.noGravity = true;
                }
                SoundEngine.PlaySound(SoundID.Item92, Owner.Center);

                // **光球充能完成，开始射击**
                shootingTimer = 0; // **重置射击计时器**
            }
        }

        private void FireProjectile()
        {
            Player owner = Main.player[Projectile.owner];
            SoundEngine.PlaySound(SoundID.Item11, Projectile.Center);

            // **确保玩家当前持有的武器可以发射弹药**
            if (!owner.HasAmmo(owner.HeldItem))
                return;

            // **创建一个假的远程武器**
            Item FakeGun = new Item();
            FakeGun.SetDefaults(ItemID.SniperRifle); // **设置它为可以使用子弹的远程武器**

            for (int i = 0; i < 2; i++)
            {
                // **是否消耗弹药**
                bool dontConsumeAmmo = Main.rand.NextBool();

                // **获取玩家当前武器的弹药**
                owner.PickAmmo(FakeGun, out int ammoProjectile, out float shootSpeed, out int damage, out float knockback, out _, dontConsumeAmmo);

                // **确保伤害不会溢出，保持与挥砍弹幕一致**
                damage = Projectile.damage; // **保持 1.0 倍伤害**

                // **计算发射位置**
                Vector2 spawnPosition = Projectile.Center + Projectile.velocity.SafeNormalize(Vector2.Zero) * 16f * 4.5f;

                // **计算发射方向**
                Vector2 velocity = (Owner.SafeDirectionTo(Main.MouseWorld)).SafeNormalize(Vector2.Zero) * shootSpeed;
                velocity = velocity.RotatedByRandom(MathHelper.PiOver4 * 0.2f); // **让弹幕稍微随机偏移**

                // **发射玩家当前武器的弹药**
                int projIndex = Projectile.NewProjectile(
                    Projectile.GetSource_FromAI(),
                    spawnPosition,
                    velocity,
                    ammoProjectile, // **使用玩家的弹药**
                    damage,
                    knockback,
                    Projectile.owner
                );

                // **如果子弹是普通弹药，转换为特殊弹幕**
                if (ammoProjectile == ProjectileID.Bullet)
                {
                    Main.projectile[projIndex].type = ModContent.ProjectileType<BlackHawkBullet>();
                }
            }
        }


        private int lightBallCounter = 0;
        private int shootingTimer = -1; // **初始化为 -1，避免未充能时射击**

        public override void OnKill(int timeLeft)
        {

        }


        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {

        }
    }
}