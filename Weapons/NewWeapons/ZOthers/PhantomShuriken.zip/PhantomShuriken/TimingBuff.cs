using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;

namespace CalamityThrowingSpear.Weapons.NewWeapons.ZOthers.PhantomShuriken
{
    internal class TimingBuff : ModBuff
    {
        public override string Texture => "CalamityMod/Projectiles/InvisibleProj";

        public override void SetStaticDefaults()
        {
            Main.debuff[Type] = true; // �趨Ϊ����Ч��
            Main.pvpBuff[Type] = true; // ������ PvP ��ʹ��
            BuffID.Sets.LongerExpertDebuff[Type] = true; // ��ר��ģʽ�г�������
        }

        public override void Update(NPC npc, ref int buffIndex)
        {
            if (!npc.boss) // ��ѡ����ֹ�� Boss ��Ч
            {
                npc.GetGlobalNPC<TimingBuffGN>().hasCustomBleed = true;
                npc.GetGlobalNPC<TimingBuffGN>().bleedDuration = npc.buffTime[buffIndex] / 60; // ����ʱ�䣨�룩
            }
        }
    }
}