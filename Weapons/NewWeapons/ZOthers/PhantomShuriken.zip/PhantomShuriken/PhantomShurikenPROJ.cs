﻿using CalamityMod.Sounds;
using CalamityMod;
using CalamityThrowingSpear.Weapons.ChangedWeapons.EAfterDog.DragonRageC;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using Microsoft.Xna.Framework.Graphics;
using Terraria.GameContent;

namespace CalamityThrowingSpear.Weapons.NewWeapons.ZOthers.PhantomShuriken
{
    public class PhantomShurikenPROJ : ModProjectile
    {
        public override string Texture => "CalamityThrowingSpear/Weapons/NewWeapons/ZOthers/PhantomShuriken";
        public override void SetStaticDefaults()
        {
            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 8;
            ProjectileID.Sets.TrailingMode[Projectile.type] = 1;
        }

        public override bool PreDraw(ref Color lightColor)
        {
            CalamityUtils.DrawAfterimagesCentered(Projectile, ProjectileID.Sets.TrailingMode[Projectile.type], lightColor, 1);
            return false;
        }

        public override void SetDefaults()
        {
            Projectile.width = 32; // 弹幕宽度
            Projectile.height = 32; // 弹幕高度
            Projectile.friendly = true; // 是否对敌人友好
            Projectile.penetrate = 4; // 最大穿透次数
            Projectile.timeLeft = 600; // 弹幕存在时间
            Projectile.usesLocalNPCImmunity = true; // 是否使用独立的NPC免疫
            Projectile.localNPCHitCooldown = 30; // NPC击中冷却时间
            Projectile.DamageType = ModContent.GetInstance<RogueDamageClass>();
            Projectile.ignoreWater = true; // 是否无视水
            Projectile.extraUpdates = 1;
        }

        public override void AI()
        {
            // 弹幕旋转逻辑
            Projectile.rotation += MathHelper.ToRadians(15f);

            // 粒子特效：DNA双链喷射
            //float angle = Projectile.ai[0];
            //Vector2 offset1 = Projectile.Center + Vector2.UnitX.RotatedBy(angle) * 16f;
            //Vector2 offset2 = Projectile.Center + Vector2.UnitX.RotatedBy(angle + MathHelper.Pi) * 16f;
            //Dust.NewDustPerfect(offset1, DustID.RedTorch, Vector2.Zero, 0, default, 1.2f);
            //Dust.NewDustPerfect(offset2, DustID.RedTorch, Vector2.Zero, 0, default, 1.2f);

            {
                // 粒子特效：复杂的DNA双链喷射逻辑
                float angle = Projectile.ai[0];

                if (Main.GameUpdateCount % 2 == 0)
                {
                    // 主DNA链：双链红色和白色粒子
                    for (int i = 0; i < 2; i++)
                    {
                        float rotationOffset = i == 0 ? 0f : MathHelper.Pi; // 一链和另一链的相对位置
                        Vector2 offset = Projectile.Center + Vector2.UnitX.RotatedBy(angle + rotationOffset) * 16f;
                        Dust dust = Dust.NewDustPerfect(offset, i == 0 ? DustID.RedTorch : DustID.LifeCrystal,
                                        Vector2.Zero, 0, default, 1.2f); // 一链用红色，另一链用白色
                        dust.noGravity = true; // 设置粒子不受重力影响
                    }
                }

                if (Main.GameUpdateCount % 1 == 0)
                {
                    // 次级链条：随机内环粒子
                    for (int j = 0; j < 3; j++)
                    {
                        float randomRadius = Main.rand.NextFloat(8f, 16f); // 内环随机半径
                        float innerAngle = angle + MathHelper.ToRadians(Main.rand.Next(120, 240)); // 随机角度
                        Vector2 innerOffset = Projectile.Center + Vector2.UnitX.RotatedBy(innerAngle) * randomRadius;
                        Dust dust = Dust.NewDustPerfect(innerOffset, DustID.GemRuby, Vector2.Zero, 0, default, Main.rand.NextFloat(0.8f, 1.5f)); // 使用红宝石粒子
                        dust.noGravity = true; // 设置粒子不受重力影响
                    }
                }

                if (Main.GameUpdateCount % 10 == 0)
                {
                    // 外部环形轨迹：旋转扩散粒子
                    int ringParticleCount = 8; // 外环粒子数量
                    for (int k = 0; k < ringParticleCount; k++)
                    {
                        float ringAngle = angle + MathHelper.TwoPi / ringParticleCount * k; // 每个粒子的角度
                        float ringRadius = 32f; // 外环半径
                        Vector2 ringOffset = Projectile.Center + Vector2.UnitX.RotatedBy(ringAngle) * ringRadius;
                        Dust dust = Dust.NewDustPerfect(ringOffset, Main.rand.NextBool() ? DustID.RedTorch : DustID.LifeCrystal,
                                        Vector2.Zero, 0, default, Main.rand.NextFloat(1f, 2f)); // 红色和白色交替
                        dust.noGravity = true; // 设置粒子不受重力影响
                    }
                }

                // 中心爆裂效果：间隔喷射爆发
                if (Main.GameUpdateCount % 30 == 0) // 每30帧触发一次
                {
                    // 爆裂粒子效果
                    int burstParticleCount = Main.rand.Next(5, 10); // 每次爆发粒子数量
                    for (int m = 0; m < burstParticleCount; m++)
                    {
                        Vector2 burstDirection = Vector2.UnitX.RotatedByRandom(MathHelper.TwoPi) * Main.rand.NextFloat(2f, 6f);
                        Dust.NewDustPerfect(Projectile.Center, DustID.GemRuby, burstDirection, 0, default, Main.rand.NextFloat(1.5f, 4f)); // 使用红宝石粒子
                    }

                    // 向正前方释放一个 PhantomShurikenBloodPROJ 弹幕
                    Vector2 forwardDirection = Projectile.velocity.SafeNormalize(Vector2.Zero); // 确保方向正常化
                    int phantomShurikenBloodProjID = ModContent.ProjectileType<PhantomShurikenBloodPROJ>(); // 获取 PhantomShurikenBloodPROJ 类型
                    Projectile.NewProjectile(
                        Projectile.GetSource_FromThis(), // 获取来源
                        Projectile.Center, // 弹幕生成位置
                        forwardDirection * 10f, // 弹幕飞行速度
                        phantomShurikenBloodProjID, // 弹幕类型
                        (int)(Projectile.damage * 0.75f), // 伤害倍率为 0.75
                        Projectile.knockBack, // 使用当前弹幕的击退值
                        Projectile.owner // 所属玩家
                    );
                }


                // 顺时针旋转角度加速
                Projectile.ai[0] += MathHelper.ToRadians(7f); // 增加旋转速度，进一步动态化
            }

            //// 飞行回追逻辑
            //if (Projectile.timeLeft < 150) // （当小于多少飞行剩余时间的时候）回追开始
            //{
            //    Vector2 returnDirection = Projectile.DirectionTo(Main.player[Projectile.owner].Center);
            //    Projectile.velocity = Vector2.Lerp(Projectile.velocity, returnDirection * 10f, 0.05f); // 平滑调整速度
            //}

            // 飞行回追逻辑
            if (Projectile.timeLeft < 480) // （当飞行剩余时间小于x时）回追开始
            {
                // 标记回追状态
                isReturning = true;

                // 计算返回方向并平滑调整速度
                Vector2 returnDirection = Projectile.DirectionTo(Main.player[Projectile.owner].Center);
                Projectile.velocity = Vector2.Lerp(Projectile.velocity, returnDirection * 10f, 0.05f); // 平滑调整速度
            }

            // 检查是否与玩家碰撞，并且回追已经开始
            Player player = Main.player[Projectile.owner];
            if (isReturning && Projectile.Hitbox.Intersects(player.Hitbox))
            {
                Projectile.Kill(); // 消除弹幕
            }
        }

        // 新增布尔变量，标记回追是否已开始
        private bool isReturning = false;

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            // 生成橙红斩击特效
            int slashCount = Main.rand.Next(1, 3); // 生成1到2个斩击
            for (int i = 0; i < slashCount; i++)
            {
                Vector2 randomDirection = Vector2.UnitX.RotatedByRandom(MathHelper.TwoPi);
                int slashID = ModContent.ProjectileType<OrangeSLASH>(); // 之前不是给过你斩杀的弹幕吗（SLASH）你直接调用那个就行了，原理都一样的
                Projectile.NewProjectile(Projectile.GetSource_FromThis(), target.Center, randomDirection, slashID, (int)(Projectile.damage * 0.25f), Projectile.knockBack, Projectile.owner);
            }

            // 播放声音
            SoundEngine.PlaySound(CommonCalamitySounds.SwiftSliceSound with { Volume = 0.5f }, Projectile.Center);

            // 附加Buff
            target.AddBuff(ModContent.BuffType<TimingBuff>(), 300); // 持续5秒
        }

        public override bool OnTileCollide(Vector2 oldVelocity)
        {
            if (Projectile.penetrate > 1)
            {
                // 反弹逻辑
                if (Projectile.velocity.X != oldVelocity.X) Projectile.velocity.X = -oldVelocity.X;
                if (Projectile.velocity.Y != oldVelocity.Y) Projectile.velocity.Y = -oldVelocity.Y;

                Projectile.penetrate--;
                return false;
            }
            else
            {
                Projectile.tileCollide = false;
                return true;
            }
        }
    }
}