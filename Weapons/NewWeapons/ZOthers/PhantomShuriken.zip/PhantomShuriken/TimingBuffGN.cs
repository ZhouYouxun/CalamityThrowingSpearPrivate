﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ModLoader;
using Terraria;

namespace CalamityThrowingSpear.Weapons.NewWeapons.ZOthers.PhantomShuriken
{
    internal class TimingBuffGN : GlobalNPC
    {
        public bool hasCustomBleed; // 是否受到自定义流血效果
        public int bleedDuration; // 流血持续时间（秒）
        private int bleedTimer; // 用于计算每秒触发

        public override bool InstancePerEntity => true; // 确保每个 NPC 独立

        public override void ResetEffects(NPC npc)
        {
            hasCustomBleed = false; // 每帧重置
            bleedDuration = 0;
        }

        public override void UpdateLifeRegen(NPC npc, ref int damage)
        {
            if (hasCustomBleed)
            {
                // 每秒触发一次掉血
                bleedTimer++;
                if (bleedTimer >= 60) // 60 帧 = 1 秒
                {
                    int damageAmount = 3 * bleedDuration; // 掉血量
                    npc.lifeRegen -= damageAmount * 2; // lifeRegen 是每秒恢复值，需乘以 2 才能反映减益效果
                    damage = Math.Max(damage, damageAmount); // 更新显示的伤害数值
                    bleedTimer = 0; // 重置计时器
                }
            }
        }
    }
}