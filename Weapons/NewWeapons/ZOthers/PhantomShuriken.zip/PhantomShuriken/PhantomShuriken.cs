﻿using CalamityMod;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using CalamityMod.Items.Weapons.Rogue;

namespace CalamityThrowingSpear.Weapons.NewWeapons.ZOthers.PhantomShuriken
{
    internal class PhantomShuriken : RogueWeapon
    {
        public override void SetDefaults()
        {
            Item.width = 32; // 武器宽度
            Item.height = 32; // 武器高度
            Item.damage = 75; // 基础伤害值
            Item.noMelee = true; // 是否不属于近战
            Item.noUseGraphic = true; // 使用时是否隐藏武器图标
            Item.autoReuse = true; // 是否自动连续使用
            Item.useAnimation = 20; // 使用动画时间
            Item.useTime = 20; // 使用间隔时间
            Item.useStyle = ItemUseStyleID.Swing; // 使用方式（挥舞）
            Item.knockBack = 5f; // 击退效果
            Item.UseSound = SoundID.Item1; // 使用时的声音
            Item.value = Item.sellPrice(gold: 10); // 售价
            Item.rare = ItemRarityID.Yellow; // 稀有度
            Item.shoot = ModContent.ProjectileType<PhantomShurikenPROJ>(); // 关联的弹幕
            Item.shootSpeed = 16f; // 发射速度
            Item.DamageType = ModContent.GetInstance<RogueDamageClass>();

        }

        public override bool Shoot(Player player, Terraria.DataStructures.EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            if (player.Calamity().StealthStrikeAvailable()) // 检查是否隐匿打击
            {
                // 隐匿打击一次投掷三个弹幕，方向略有偏差
                for (int i = -1; i <= 1; i++)
                {
                    Vector2 perturbedVelocity = velocity.RotatedBy(MathHelper.ToRadians(10 * i));
                    Projectile.NewProjectile(source, position, perturbedVelocity, type, damage, knockback, player.whoAmI);
                }
                return false;
            }

            // 普通情况下发射一个弹幕
            Projectile.NewProjectile(source, position, velocity, type, damage, knockback, player.whoAmI);
            return false;
        }
    }
}