﻿using CalamityMod;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using CalamityMod.Buffs.DamageOverTime;
using CalamityMod.Buffs.StatDebuffs;
using CalamityMod.Particles;
using CalamityMod.Projectiles.Typeless;
using CalamityMod.Projectiles.Melee;
using Terraria.DataStructures;

namespace CalamityThrowingSpear.Weapons.NewWeapons.EAfterDog.ArkofTheDragonSoul
{
    public class ArkofTheDragonSoulBlade : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 8;
            ProjectileID.Sets.TrailingMode[Projectile.type] = 2;
        }
        public override bool PreDraw(ref Color lightColor)
        {
            CalamityUtils.DrawAfterimagesCentered(Projectile, ProjectileID.Sets.TrailingMode[Projectile.type], lightColor, 1);
            return false;
        }

        public override void SetDefaults()
        {
            Projectile.width = Projectile.height = 32;
            Projectile.friendly = true;
            Projectile.hostile = false;
            Projectile.DamageType = DamageClass.Melee;
            Projectile.penetrate = 1;
            Projectile.timeLeft = 450;
            Projectile.light = 0.5f;
            Projectile.ignoreWater = true;
            Projectile.tileCollide = true; // 允许与方块碰撞
            Projectile.extraUpdates = 2; // 额外更新次数
            Projectile.usesLocalNPCImmunity = true; // 弹幕使用本地无敌帧
            Projectile.localNPCHitCooldown = 1; // 无敌帧冷却时间为1帧
            Projectile.scale = 0.75f; // 大小小一点
        }
        public override void OnSpawn(IEntitySource source)
        {
            // 每次弹幕生成时，在主弹幕面向方向的左右 45 度范围内挑选两个随机角度释放 ADSEonBolt
            int boltsToSpawn = 2; // 要生成的 ADSEonBolt 数量
            float angleRange = MathHelper.PiOver4; // 45 度的范围

            for (int i = 0; i < boltsToSpawn; i++)
            {
                // 随机选择角度
                float randomAngle = Main.rand.NextFloat(-angleRange, angleRange);

                // 计算随机方向的单位向量并增加初始速度
                Vector2 boltDirection = Projectile.velocity.RotatedBy(randomAngle).SafeNormalize(Vector2.UnitX) * (10f * 2.5f); // 弹幕初始速度变为原来的 2.5 倍

                // 生成 ADSEonBolt 弹幕
                Projectile.NewProjectile(
                    Projectile.GetSource_FromThis(),
                    Projectile.Center, // 主弹幕的当前位置
                    boltDirection, // 方向为随机角度
                    ModContent.ProjectileType<ADSEonBolt>(), // 弹幕类型
                    (int)(Projectile.damage * 1.0f), // 伤害倍率为 1.0
                    Projectile.knockBack, // 使用主弹幕的击退值
                    Main.myPlayer
                );
            }
        }
        public bool ableToHit = true;
        public override void AI()
        {
            // 保持弹幕旋转（对于倾斜走向的弹幕而言）
            Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver4;

            // 特效 1：每 2 帧在后方和右侧扩散 20 度，随机生成两个粒子
            if (Projectile.timeLeft % 2 == 0)
            {
                for (int i = 0; i < 2; i++) // 每次生成两个粒子
                {
                    float randomAngle = Main.rand.NextFloat(-20f, 20f) * (MathF.PI / 180f); // -20° 到 +20° 转为弧度
                    Vector2 particleDirection = Projectile.velocity.RotatedBy(randomAngle); // 调整角度
                    Vector2 spawnPosition = Projectile.Center - Projectile.velocity + particleDirection;

                    PointParticle spark = new PointParticle(
                        spawnPosition,
                        particleDirection * 0.5f, // 粒子移动速度
                        false, // 是否跟踪
                        15,    // 粒子存活时间
                        1.1f,  // 粒子大小
                        Color.Orange // 粒子颜色
                    );

                    GeneralParticleHandler.SpawnParticle(spark);
                }
            }

            // 特效 2：每 3 帧在前方左右扩散 20 度，随机生成一种粒子效果
            if (Projectile.timeLeft % 3 == 0)
            {
                Vector2 basePosition = Projectile.Center;
                float randomAngle = Main.rand.NextFloat(-20f, 20f) * (MathF.PI / 180f); // -20° 到 +20° 转为弧度
                Vector2 particlePosition = basePosition + Projectile.velocity.RotatedBy(randomAngle) * Main.rand.NextFloat(8f, 12f); // 在偏移范围内生成

                // 随机选择粒子颜色
                Color particleColor = Main.rand.NextBool() ? Color.OrangeRed : Main.rand.NextBool() ? Color.White : Color.Orange;
                float particleScale = Main.rand.NextFloat(0.2f, 0.5f);

                // 随机选择粒子类型并生成
                int particleType = Main.rand.Next(3);
                switch (particleType)
                {
                    case 0:
                        Vector2 strongBloomVelocity = Vector2.UnitX.RotatedByRandom(MathHelper.TwoPi) * Main.rand.NextFloat(2f, 4f) * 0.33f; // 减速到33%
                        GeneralParticleHandler.SpawnParticle(new StrongBloom(particlePosition, strongBloomVelocity, particleColor, particleScale, Main.rand.Next(20) + 10));
                        break;

                    case 1:
                        Vector2 genericBloomVelocity = Main.rand.NextVector2Circular(3f, 3f) * 0.33f;
                        GeneralParticleHandler.SpawnParticle(new GenericBloom(particlePosition, genericBloomVelocity, particleColor, particleScale, Main.rand.Next(20) + 10));
                        break;

                    case 2:
                        Vector2 critSparkVelocity = -Projectile.velocity * Main.rand.NextFloat(0.5f, 1.5f) * 0.33f;
                        GeneralParticleHandler.SpawnParticle(new CritSpark(particlePosition, critSparkVelocity, Color.White, particleColor, particleScale * 5f, Main.rand.Next(20) + 10, 0.1f, 3));
                        break;
                }
            }


            // 前x帧不追踪，之后开始追踪敌人
            if (Projectile.ai[1] > 50)
            {
                NPC target = Projectile.Center.ClosestNPCAt(5800); // 查找范围内最近的敌人
                if (target != null)
                {
                    Vector2 direction = (target.Center - Projectile.Center).SafeNormalize(Vector2.Zero);
                    Projectile.velocity = Vector2.Lerp(Projectile.velocity, direction * 18f, 0.08f); // 追踪速度为xf
                }
            }
            else
            {
                Projectile.ai[1]++;
            }

        }



        public override void OnKill(int timeLeft)
        {
            Vector2 center = Projectile.Center; // 粒子生成的中心点
            int totalParticles = 25; // 圆形粒子数量
            float particleSpeed = 6f * 2f; // 粒子速度
            float radius = 24f * 4f; // 圆形半径

            for (int i = 0; i < totalParticles; i++)
            {
                // 计算每个粒子的角度（0 到 2 * PI，即 360°）
                float angle = MathF.Tau * (i / (float)totalParticles);
                Vector2 offset = new Vector2(MathF.Cos(angle), MathF.Sin(angle)) * radius; // 偏移量
                Vector2 critSparkVelocity = offset.SafeNormalize(Vector2.Zero) * particleSpeed; // 粒子速度方向

                // 调整颜色亮度到 50%
                Color startColor = new Color(
                    (int)(Color.White.R * 0.5f),
                    (int)(Color.White.G * 0.5f),
                    (int)(Color.White.B * 0.5f),
                    Color.White.A // 保持透明度不变
                );
                Color endColor = new Color(
                    (int)(Color.Orange.R * 0.5f),
                    (int)(Color.Orange.G * 0.5f),
                    (int)(Color.Orange.B * 0.5f),
                    Color.Orange.A // 保持透明度不变
                );

                // 生成 CritSpark 粒子
                GeneralParticleHandler.SpawnParticle(
                    new CritSpark(
                        center + offset,            // 粒子生成位置
                        critSparkVelocity,          // 粒子速度
                        startColor,                 // 粒子起始颜色
                        endColor,                   // 粒子结束颜色
                        3f,                         // 粒子缩放大小
                        Main.rand.Next(80) + 20,    // 粒子存活时间
                        0.1f,                       // 粒子旋转速率
                        3                           // 粒子类型（常量）
                    )
                );
            }
        }


        private static int hitCounter = 0; // 计数器用于触发每5次击中效果
        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            target.AddBuff(BuffID.Electrified, 300);
            target.AddBuff(ModContent.BuffType<GalvanicCorrosion> (), 180);
            target.AddBuff(ModContent.BuffType<Dragonfire>(), 180);
            target.AddBuff(ModContent.BuffType<GodSlayerInferno>(), 180);
            target.AddBuff(ModContent.BuffType<ElementalMix>(), 180);

            // 每次击中释放x个 SkyFlareFriendly 弹幕
            int extraProjectileCount = 7;
            float radius = 40 * 16f; // 圆周半径
            for (int i = 0; i < extraProjectileCount; i++)
            {
                Vector2 spawnPos = Projectile.Center + Main.rand.NextVector2Circular(radius, radius);
                Vector2 direction = (Projectile.Center - spawnPos).SafeNormalize(Vector2.Zero);

                Projectile.NewProjectile(
                    Projectile.GetSource_FromThis(),
                    spawnPos,
                    direction * 20f, // 让他初始速度快一点
                    ModContent.ProjectileType<SkyFlareFriendly>(),
                    (int)(Projectile.damage * 1.0f),
                    Projectile.knockBack,
                    Main.myPlayer
                );

                // 在召唤位置释放熔岩Dust组成的正方形
                //ReleaseSquareParticles(spawnPos);
            }

            // 计数每次击中
            hitCounter++;
            if (hitCounter >= 5)
            {
                hitCounter = 0; // 重置计数器

                // 基础方向（当前弹幕的方向）
                Vector2 baseDirection = Projectile.velocity.SafeNormalize(Vector2.Zero);

                // 弹幕生成的角度偏移
                float[] angles = { 0f, MathF.PI * 2f / 3f, -MathF.PI * 2f / 3f }; // 0°，+120°，-120°

                // 生成三个 ArkofTheDragonSoulBlast 弹幕
                foreach (float angle in angles)
                {
                    // 根据偏移角度计算方向
                    Vector2 blastDirection = baseDirection.RotatedBy(angle);

                    // 生成 ArkofTheDragonSoulBlast
                    Projectile.NewProjectile(
                        Projectile.GetSource_FromThis(),
                        target.Center, // 初始位置为击中目标的位置
                        blastDirection * 10f, // 初始速度，方向偏转后的向量
                        ModContent.ProjectileType<ArkofTheDragonSoulBlast>(),
                        (int)(Projectile.damage * 15.0f), // 伤害倍率为 15.0
                        Projectile.knockBack,
                        Main.myPlayer
                    );
                }
            }
        }

        private void ReleaseSquareParticles(Vector2 center)
        {
            for (int i = 0; i < 4; i++)
            {
                float angle = MathHelper.PiOver4 + i * MathHelper.PiOver2;
                float nextAngle = MathHelper.PiOver4 + (i + 1) * MathHelper.PiOver2;

                Vector2 start = angle.ToRotationVector2() * (16f / 2f);
                Vector2 end = nextAngle.ToRotationVector2() * (16f / 2f);

                for (int j = 0; j < 40; j++)
                {
                    Dust squareDust = Dust.NewDustPerfect(center, DustID.Lava);
                    squareDust.scale = 1.8f; // 缩小粒子尺寸
                    squareDust.velocity = Vector2.Lerp(start, end, j / 40f) * 0.6f; // 缓慢移动
                    squareDust.color = new Color(255, 80, 0); // 熔岩的橙红色
                    squareDust.noGravity = true;
                }
            }
        }

    }
}
