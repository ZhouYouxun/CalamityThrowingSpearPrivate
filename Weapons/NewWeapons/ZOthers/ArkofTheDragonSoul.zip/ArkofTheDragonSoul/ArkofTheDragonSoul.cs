﻿using CalamityMod.Items;
using CalamityMod.Rarities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using CalamityMod.Items.Materials;
using CalamityMod.Items.Weapons.Melee;
using CalamityMod.Tiles.Furniture.CraftingStations;
using static Terraria.ModLoader.ModContent;
using System.Security.Cryptography;
using System.IO;
using System.IO.Pipelines;
using CalamityMod.Items.Weapons.Rogue;


namespace CalamityThrowingSpear.Weapons.NewWeapons.EAfterDog.ArkofTheDragonSoul
{
    public class ArkofTheDragonSoul : ModItem
    {
        public override void SetStaticDefaults()
        {
            ItemID.Sets.ItemsThatAllowRepeatedRightClick[Item.type] = true;
        }
        public override bool AltFunctionUse(Player player) => true;
        public override void SetDefaults()
        {
            Item.width = 128;
            Item.height = 140;
            Item.damage = 2075;
            Item.knockBack = 7.5f;
            Item.useAnimation = Item.useTime = 25;
            Item.useLimitPerAnimation = 1;
            Item.DamageType = DamageClass.MeleeNoSpeed; // 设置为近战武器
            Item.noMelee = true;
            Item.channel = true;
            Item.autoReuse = true;
            Item.shootSpeed = 14f;
            Item.shoot = ModContent.ProjectileType<ArkofTheDragonSoulPROJ>();

            Item.noUseGraphic = true;
            Item.useStyle = ItemUseStyleID.Shoot;
            Item.UseSound = SoundID.DD2_SkyDragonsFurySwing;
            Item.value = CalamityGlobalItem.RarityVioletBuyPrice;
            Item.rare = ModContent.RarityType<Violet>();
        }
        public override bool CanUseItem(Player player)
        {
            if (player.altFunctionUse == 2) // 检测右键
            {
                // 右键攻击属性（二连发）
                Item.useTime = 22;
                Item.useAnimation = 75;
                Item.useLimitPerAnimation = 2;
                Item.damage = 1111;
                Item.useStyle = ItemUseStyleID.Swing;
                Item.UseSound = SoundID.Item71;
                Item.shootSpeed = 15f;
                Item.shoot = ModContent.ProjectileType<ArkofTheDragonSoulBlade>();
            }
            else
            {
                // 左键攻击属性（恢复默认）
                Item.useAnimation = Item.useTime = 25;
                Item.useLimitPerAnimation = 1;
                Item.damage = 2222;
                Item.useStyle = ItemUseStyleID.Shoot;
                Item.UseSound = SoundID.DD2_SkyDragonsFurySwing;
                Item.shootSpeed = 14f;
                Item.shoot = ModContent.ProjectileType<ArkofTheDragonSoulPROJ>();
            }
            return base.CanUseItem(player);
        }
        public override void ModifyWeaponDamage(Player player, ref StatModifier damage)
        {
            base.ModifyWeaponDamage(player, ref damage);
        }

        public override void AddRecipes()
        {
            Recipe recipe = CreateRecipe();
            //recipe.AddIngredient(ItemID.MonkStaffT1, 1); // 瞌睡章鱼
            //recipe.AddIngredient<TyphonsGreed>(1); // 提风贪婪
            //recipe.AddIngredient(ItemID.MonkStaffT3, 1); // 天龙之怒
            recipe.AddIngredient<DragonRage>(1); // 巨龙之怒
            recipe.AddIngredient<ArkoftheCosmos>(1); // 宇宙方舟

            //recipe.AddIngredient<AstralPike>(1); // 幻星矛
            //recipe.AddIngredient<StreamGouge>(1); // 宇宙暗流
            //recipe.AddIngredient<DarklightGreatsword>(1); // 巨剑“夜光”
            //recipe.AddIngredient<ArkoftheElements>(1); // 元素方舟
            //recipe.AddIngredient<FourSeasonsGalaxia>(1); // 四季-盖利克西亚
            //recipe.AddIngredient<TheAtomSplitter>(1); // 微元劫裂者
            recipe.AddIngredient<ShadowspecBar>(5);
            recipe.AddTile(TileType<DraedonsForge>());
            recipe.Register();
        }

    }
}



/*
名字：
龙魂方舟

描述：
按住左键旋转龙魂方舟，时不时的发射两枚具备追踪能力的星空雷
以极高的频率切割敌人，每命中30次释放一圈火球并召唤来自远方的追踪星
点击右键将龙魂方舟拆成两半并丢出去，伴随着两颗星空雷
龙魂方舟命中后从意想不到的地方召唤多个高速陨石
每命中敌人五次召唤三条宇宙撕裂，造成极高的伤害

 
 
 
 
 
 
 */






