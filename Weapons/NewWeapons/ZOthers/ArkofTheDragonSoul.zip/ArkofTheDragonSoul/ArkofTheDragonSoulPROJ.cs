﻿using CalamityMod.Buffs.DamageOverTime;
using CalamityMod.CalPlayer;
using CalamityMod.Projectiles.Melee;
using CalamityMod.Projectiles.Typeless;
using CalamityMod;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.Enums;
using Terraria.ID;
using Terraria;
using Terraria.ModLoader;
using CalamityMod.Particles;
using Terraria.Graphics.Shaders;
using CalamityMod.Graphics.Metaballs;
using CalamityMod.Sounds;
using Terraria.Audio;
using CalamityMod.Graphics.Primitives;

namespace CalamityThrowingSpear.Weapons.NewWeapons.EAfterDog.ArkofTheDragonSoul
{
    public class ArkofTheDragonSoulPROJ : ModProjectile
    {
        public override string Texture => "CalamityThrowingSpear/Weapons/NewWeapons/EAfterDog/ArkofTheDragonSoul/ArkofTheDragonSoul";

        public override void SetDefaults()
        {
            Projectile.width = Projectile.height = 408;
            Projectile.DamageType = DamageClass.Melee;
            Projectile.friendly = true;
            Projectile.penetrate = -1;
            Projectile.timeLeft = 90000;
            Projectile.tileCollide = false;
            Projectile.ignoreWater = true;
            Projectile.alpha = 255;
            Projectile.hide = true;
            Projectile.usesLocalNPCImmunity = true;
            Projectile.localNPCHitCooldown = 5;
            Projectile.scale = 1.75f;
        }
        private int timer = 0; // 添加一个私有计时器变量

        public override void AI()
        {
            Player player = Main.player[Projectile.owner];
            float spinCycleTime = 50f;

            // If the player is dead, destroy the projectile
            if (player.dead || !player.channel)
            {
                Projectile.Kill();
                player.reuseDelay = 2;
                return;
            }

            int direction = Math.Sign(Projectile.velocity.X);
            Projectile.velocity = new Vector2(direction, 0f);

            // Initial Rotation
            if (Projectile.ai[0] == 0f)
            {
                Projectile.rotation = new Vector2(direction, -player.gravDir).ToRotation() + MathHelper.ToRadians(135f);
                if (Projectile.velocity.X < 0f)
                {
                    Projectile.rotation -= MathHelper.PiOver2;
                }
            }

            Projectile.ai[0] += 1f;
            Projectile.rotation += MathHelper.TwoPi * 2f / spinCycleTime * direction;
            int expectedDirection = (player.SafeDirectionTo(Main.MouseWorld).X > 0f).ToDirectionInt();
            if (Projectile.ai[0] % spinCycleTime > spinCycleTime * 0.5f && expectedDirection != Projectile.velocity.X)
            {
                player.ChangeDir(expectedDirection);
                Projectile.velocity = Vector2.UnitX * expectedDirection;
                Projectile.rotation -= MathHelper.Pi;
                Projectile.netUpdate = true;
            }
            SpawnDust(player, direction);
            PositionAndRotation(player);
            VisibilityAndLight();

            // 每25帧触发一次弹幕发射
            if (Projectile.ai[0] % 25 == 0)
            {
                int loopCount = Main.zenithWorld ? 9 : 4;

                for (int i = 0; i < loopCount; i++)
                {
                    // 随机角度
                    float angle = Main.rand.NextFloat(MathHelper.TwoPi);
                    Vector2 velocity = new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle)) * 30f; // 固定速度 x0f

                    // 发射 ADSEonBolt
                    Projectile.NewProjectile(Projectile.GetSource_FromThis(), player.Center, velocity, ModContent.ProjectileType<ADSEonBolt>(), (int)(Projectile.damage * 1.0f), Projectile.knockBack, Projectile.owner);

                    // 添加粒子效果
                    for (int j = 0; j < 20; j++)
                    {
                        Vector2 dustVelocity = velocity.RotatedByRandom(MathHelper.PiOver4) * Main.rand.NextFloat(0.5f, 1.5f);
                        Dust dust = Dust.NewDustDirect(player.Center, 0, 0, Main.rand.Next(new int[] { DustID.BlueTorch, DustID.PurpleTorch, DustID.CursedTorch }), dustVelocity.X, dustVelocity.Y, 100, default, 1.5f);
                        dust.noGravity = true;
                        dust.scale *= Main.rand.NextFloat(0.8f, 1.2f);
                    }
                }
            }
                     
            // 每x帧生成一次粒子特效（重型烟雾）
            if (Projectile.ai[0] % 1 == 0)
            {
                // 定义随机颜色列表
                Color[] possibleColors = new Color[]
                {
        Color.Orange,
        Color.White,
        Color.Purple,
        Color.Blue,
        Color.Gray
                };

                // 从颜色列表中随机选择一个
                Color smokeColor = possibleColors[Main.rand.Next(possibleColors.Length)];

                // 在玩家为中心的半径18个方块范围内随机生成位置
                Vector2 randomPosition = player.Center + Main.rand.NextVector2Circular(18 * 16, 18 * 16);

                // 计算从玩家到生成位置的方向向量
                Vector2 directionToParticle = (randomPosition - player.Center).SafeNormalize(Vector2.Zero);

                // 根据鼠标位置决定弯折方向
                Vector2 velocity;
                if (Main.MouseWorld.X >= Main.screenPosition.X + (Main.screenWidth / 2)) // 鼠标在右半屏幕
                {
                    velocity = directionToParticle.RotatedBy(MathHelper.PiOver2); // 顺时针弯折90度
                }
                else // 鼠标在左半屏幕
                {
                    velocity = directionToParticle.RotatedBy(-MathHelper.PiOver2); // 逆时针弯折90度
                }

                velocity *= Main.rand.NextFloat(15f, 30f); // 设置速度范围

                // 创建并生成重型烟雾粒子，大小缩减到40%
                Particle smoke = new HeavySmokeParticle(
                    randomPosition,
                    velocity, // 使用根据鼠标位置计算的速度
                    smokeColor,
                    30, // 粒子持续时间
                    Projectile.scale * 0.4f * Main.rand.NextFloat(0.7f, 1.3f), // 粒子大小缩减为40%
                    1.0f,
                    MathHelper.ToRadians(2f),
                    required: true
                );

                GeneralParticleHandler.SpawnParticle(smoke);
            }

            timer++; // 每帧递增计时器
            // 粒子效果随机化释放（圆盘刀光）
            if (timer % 5 == 0) // 每 5 帧释放一次
            {
                Vector2 particleOffset = new Vector2(13.5f * Projectile.direction, 0);
                particleOffset.X += Main.rand.NextFloat(-3f, 3f); // 随机左右偏移
                Vector2 particlePosition = Projectile.Center + particleOffset + Projectile.velocity * 0.5f;

                float scaleMultiplier = 3.1f;
                Particle Smear = new CircularSmearVFX(
                    particlePosition,
                    Color.OrangeRed * Main.rand.NextFloat(0.78f, 0.85f),
                    Main.rand.NextFloat(-8, 8),
                    Main.rand.NextFloat(1.2f, 1.3f) * scaleMultiplier
                );
                GeneralParticleHandler.SpawnParticle(Smear);
            }
        }


        // 增加一个本地计时器变量
        private int dustCooldown = 0;

        private void SpawnDust(Player player, int direction)
        {
            float rotationSpeed = MathHelper.PiOver4; // 每帧旋转速度
                                                      // 基于时间的平滑浮动
            float waveFrequency = 0.05f; // 控制波动频率
            float waveAmplitude = 50f; // 控制波动幅度（半径从100到200的差为50）
            float baseRadius = 150f; // 平均半径为(100 + 200) / 2
            float radius = baseRadius + waveAmplitude * (float)Math.Sin(Main.GameUpdateCount * waveFrequency); // 波浪形浮动

            float rotationOffset = Projectile.ai[1];

            // 更新旋转角度
            rotationOffset += rotationSpeed;
            Projectile.ai[1] = rotationOffset;

            Vector2 center = player.Center;

            // 检查冷却计时器是否到达0
            if (dustCooldown <= 0)
            {
                rotationOffset = Projectile.ai[1];
                center = player.Center;

                // 每隔一个随机帧生成特效
                dustCooldown = Main.rand.Next(1, 6); // 重置冷却时间，随机1到5帧

                // 两个顶点，各自相间180度
                for (int i = 0; i < 2; i++)
                {
                    float angle = MathHelper.Pi * i + rotationOffset; // 两顶点相间180度
                    Vector2 position = center + new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle)) * radius;

                    int particleCount = Main.rand.Next(2, 4); // 每次释放2~3发粒子
                    for (int k = 0; k < particleCount; k++)
                    {
                        // 随机偏移角度，范围 +-30度
                        float angleOffset = MathHelper.ToRadians(Main.rand.NextFloat(-30f, 30f));
                        Vector2 spawnDirection = new Vector2((float)Math.Cos(angle + angleOffset), (float)Math.Sin(angle + angleOffset));
                        Vector2 velocity = spawnDirection * Main.rand.NextFloat(3f, 7f); // 更快的速度范围

                        if (i == 0)
                        {
                            // CritSpark 特效
                            Color critColor = Color.Lerp(Color.White, Color.Orange, Main.rand.NextFloat()); // 动态混合色
                            GeneralParticleHandler.SpawnParticle(new CritSpark(
                                position,
                                velocity,
                                critColor,
                                critColor * 0.7f,
                                1.5f,
                                Main.rand.Next(20) + 10,
                                Main.rand.NextFloat(0.08f, 0.12f),
                                Main.rand.Next(2, 5))); // 随机化尾迹长度
                        }
                        else if (i == 1)
                        {
                            // StrongBloom 和 GenericBloom 的混合特效
                            Color bloomColor = Main.rand.Next(2) == 0
                                ? Color.Lerp(Color.Orange, Color.Red, Main.rand.NextFloat())
                                : Color.Lerp(Color.Orange, Color.Yellow, Main.rand.NextFloat());

                            if (Main.rand.Next(2) == 0)
                            {
                                // StrongBloom 特效
                                GeneralParticleHandler.SpawnParticle(new StrongBloom(
                                    position,
                                    velocity * 0.75f, // 调整速度
                                    bloomColor,
                                    0.25f,
                                    Main.rand.Next(20) + 10));
                            }
                            else
                            {
                                // GenericBloom 特效
                                GeneralParticleHandler.SpawnParticle(new GenericBloom(
                                    position,
                                    velocity * 0.85f, // 调整速度
                                    bloomColor,
                                    0.25f,
                                    Main.rand.Next(20) + 10));
                            }
                        }
                    }
                }
            }
            else
            {
                // 减少冷却计时器
                dustCooldown--;
            }
        }



        // 控制旋转
        private void PositionAndRotation(Player player)
        {
            Vector2 plrCtr = player.RotatedRelativePoint(player.MountedCenter, true);
            Vector2 offset = Vector2.Zero;
            Projectile.Center = plrCtr + offset;
            Projectile.spriteDirection = Projectile.direction;
            Projectile.timeLeft = 2;
            player.ChangeDir(Projectile.direction);
            player.heldProj = Projectile.whoAmI;
            player.itemTime = player.itemAnimation = 2;
            player.itemRotation = MathHelper.WrapAngle(Projectile.rotation);
        }

        // 控制亮度
        private void VisibilityAndLight()
        {
            Lighting.AddLight(Projectile.Center, 1.45f, 1.22f, 0.58f);
            Projectile.alpha -= 128;
            if (Projectile.alpha < 0)
            {
                Projectile.alpha = 0;
            }
        }
        // 添加一个全局击中计数器（专为斩杀音效设计）
        private int hitSoundCounter = 0;

        // 添加一个额外的击中计数器用于触发 OnExplosionsOccur
        private int explosionHitCounter = 0;

        // 击中时计算，发射火球
        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            target.AddBuff(ModContent.BuffType<Dragonfire>(), 180);
            target.AddBuff(ModContent.BuffType<GodSlayerInferno>(), 180);
            target.AddBuff(ModContent.BuffType<ElementalMix>(), 180);

            // 增加击中计数器
            hitSoundCounter++;
            explosionHitCounter++;

            // 生成宇宙能量光球粒子效果
            Vector2[] directions =
            {
        new Vector2(-1, -1), // 左上
        new Vector2(1, -1),  // 右上
        new Vector2(-1, 1),  // 左下
        new Vector2(1, 1)    // 右下
    };

            foreach (var dir in directions)
            {
                for (int i = 0; i < 2; i++) // 每个方向射出两发
                {
                    Vector2 normalizedDir = dir.SafeNormalize(Vector2.Zero);
                    Vector2 spawnPosition = target.Center + normalizedDir * Main.rand.NextFloat(30f, 90f); // 随机位置偏移

                    // 生成第一个粒子
                    StreamGougeMetaball.SpawnParticle(spawnPosition, Main.rand.NextVector2Circular(3f, 3f), 60f);

                    // 生成第二个动态粒子
                    float scale = MathHelper.Lerp(24f, 64f, CalamityUtils.Convert01To010(i / 1f)); // 根据发射次序调整比例
                    Vector2 particleVelocity = normalizedDir * Main.rand.NextFloat(2.5f, 9f); // 固定方向的随机速度
                    StreamGougeMetaball.SpawnParticle(spawnPosition, particleVelocity, scale);
                }
            }

            // 发射 ADSHit
            int proj = Projectile.NewProjectile(
                Projectile.GetSource_FromThis(),
                target.Center,
                Vector2.Zero,
                ModContent.ProjectileType<ADSSlash>(),
                Projectile.damage / 4,
                Projectile.knockBack,
                Projectile.owner,
                0f,
                0.85f + Main.rand.NextFloat() * 1.15f
            );

            Main.projectile[proj].DamageType = DamageClass.Melee;

            // 播放音效，每5次击中播放一次
            if (hitSoundCounter % 2 == 0)
            {
                SoundEngine.PlaySound(CommonCalamitySounds.SwiftSliceSound with
                {
                    Volume = CommonCalamitySounds.SwiftSliceSound.Volume * 0.5f
                }, Projectile.Center);
            }

            // 每35次击中触发 OnExplosionsOccur
            if (explosionHitCounter >= 35)
            {
                OnExplosionsOccur(); // 从屏幕外发出大量的星星
                SpawnFireballs(); // 发射大量火球
                explosionHitCounter = 0; // 重置计数器
            }
        }

        private void SpawnFireballs()
        {
            // 10 to 15 fireballs
            int fireballAmt = Main.rand.Next(10, 16);
            if (Main.zenithWorld)
            {
                fireballAmt = Main.rand.Next(20, 32);
            }
            for (int i = 0; i < fireballAmt; i++)
            {
                float angleStep = MathHelper.TwoPi / fireballAmt;
                float speed = 20f;
                Vector2 velocity = new Vector2(0f, speed);
                velocity = velocity.RotatedBy(angleStep * i * Main.rand.NextFloat(0.9f, 1.1f));

                Projectile.NewProjectile(Projectile.GetSource_FromThis(), Projectile.Center, velocity, ModContent.ProjectileType<DragonRageFireball>(), Projectile.damage / 8, Projectile.knockBack / 3f, Projectile.owner);
            }
            Main.player[Projectile.owner].Calamity().dragonRageCooldown = 60;
        }

        // 本地计数器
        private int localHitCounter = 0;

        // 每击中一定次数就发射很多星星
        private void OnExplosionsOccur()
        {
            Player player = Main.player[Projectile.owner];
            int pointCount = Main.rand.Next(6, 13); // 随机生成6到12个点

            if (Main.zenithWorld)
            {
                pointCount = Main.rand.Next(15, 31); // 随机生成15到30个点
            }

            float radius = 1600f; // 半径为1600

            for (int i = 0; i < pointCount; i++)
            {
                // 随机圆周点
                float angle = MathHelper.TwoPi * i / pointCount + Main.rand.NextFloat(-MathHelper.PiOver4, MathHelper.PiOver4);
                Vector2 spawnPosition = player.Center + new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle)) * radius;

                // 生成法阵粒子特效
                PointParticle spark = new PointParticle(spawnPosition, Vector2.Zero, false, 15, 1.1f, Color.Purple);
                GeneralParticleHandler.SpawnParticle(spark);

                // 发射 ADSSlash
                Vector2 velocity = player.Center - spawnPosition;
                velocity.Normalize();
                velocity *= 20f * 0.2f; // 初始速度变为当前的 0.2 倍

                Projectile.NewProjectile(
                    Projectile.GetSource_FromThis(),
                    spawnPosition,
                    velocity,
                    ModContent.ProjectileType<ADSStar>(),
                    (int)(Projectile.damage * 1.0f),
                    Projectile.knockBack,
                    Projectile.owner
                );
            }
        }

        // 着色器效果 负责绘制旋转的着色器
        internal float PrimitiveWidthFunction(float completionRatio)
        {
            float tipWidthFactor = MathHelper.SmoothStep(0f, 1f, Utils.GetLerpValue(0.01f, 0.04f, completionRatio));
            float bodyWidthFactor = (float)Math.Pow(Utils.GetLerpValue(1f, 0.04f, completionRatio), 0.9D);
            return (float)Math.Pow(tipWidthFactor * bodyWidthFactor, 0.1D) * 30f;
        }

        internal Color PrimitiveColorFunction(float completionRatio)
        {
            float fadeInterpolant = (float)Math.Cos(Main.GlobalTimeWrappedHourly * -9f + completionRatio * 6f + Projectile.identity * 2f) * 0.5f + 0.5f;

            // 动态蓝紫色渐变
            fadeInterpolant = MathHelper.Lerp(0.2f, 0.8f, fadeInterpolant);
            Color frontFade = Color.Lerp(Color.Blue, Color.Purple, fadeInterpolant);
            frontFade = Color.Lerp(frontFade, Color.DarkSlateBlue, 0.5f); // 更深色的蓝紫渐变
            Color backFade = Color.Blue;

            return Color.Lerp(frontFade, backFade, (float)Math.Pow(completionRatio, 1.2D)) * (float)Math.Pow(1f - completionRatio, 1.1D) * Projectile.Opacity;
        }


        public override bool PreDraw(ref Color lightColor)
        {
            // 旋转弹幕本体的绘制
            {
                Texture2D tex = Terraria.GameContent.TextureAssets.Projectile[Projectile.type].Value;
                Vector2 drawPos = Projectile.Center - Main.screenPosition + new Vector2(0f, Projectile.gfxOffY);
                Rectangle rectangle = new Rectangle(0, 0, tex.Width, tex.Height);
                Vector2 origin = tex.Size() / 2f;
                SpriteEffects spriteEffects = SpriteEffects.None;
                if (Projectile.spriteDirection == -1)
                    spriteEffects = SpriteEffects.FlipHorizontally;

                Main.EntitySpriteDraw(tex, drawPos, new Microsoft.Xna.Framework.Rectangle?(rectangle), lightColor, Projectile.rotation, origin, Projectile.scale, spriteEffects, 0);
            }

            // 下面是着色器的调用和绘制
            {
                GameShaders.Misc["CalamityMod:TrailStreak"].SetShaderTexture(ModContent.Request<Texture2D>("CalamityMod/ExtraTextures/Trails/FabstaffStreak"));

                Texture2D projectileTexture = Terraria.GameContent.TextureAssets.Projectile[Projectile.type].Value;

                // 克隆历史位置用于渲染
                Vector2[] drawPoints = (Vector2[])Projectile.oldPos.Clone();
                Vector2 aimAheadDirection = (Projectile.rotation - MathHelper.PiOver2).ToRotationVector2();

                if (Projectile.owner == Main.myPlayer)
                {
                    drawPoints[0] += aimAheadDirection * -12f;
                    drawPoints[1] = drawPoints[0] - (Projectile.rotation + MathHelper.PiOver4).ToRotationVector2() * Vector2.Distance(drawPoints[0], drawPoints[1]);
                }

                for (int i = 0; i < drawPoints.Length; i++)
                {
                    drawPoints[i] -= (Projectile.oldRot[i] + MathHelper.PiOver4).ToRotationVector2() * Projectile.height * 0.5f;
                }

                // 渲染轨迹
                if (Projectile.ai[0] > Projectile.oldPos.Length)
                {
                    int numPointsRendered = 24; // 渲染点数
                    PrimitiveRenderer.RenderTrail(drawPoints, new(PrimitiveWidthFunction, PrimitiveColorFunction, (_) => Projectile.Size * 0.5f, shader: GameShaders.Misc["CalamityMod:TrailStreak"], smoothen: true), numPointsRendered);
                }

                // 绘制投射物本体及残影
                Vector2 drawPosition = Projectile.Center - Main.screenPosition;
                for (int i = 0; i < 6; i++)
                {
                    float rotation = Projectile.oldRot[i] - MathHelper.PiOver2;
                    if (Projectile.owner == Main.myPlayer)
                    {
                        rotation += 0.2f;
                    }

                    Color afterimageColor = Color.Lerp(lightColor, Color.Transparent, 1f - (float)Math.Pow(Utils.GetLerpValue(0, 6, i), 1.4D)) * Projectile.Opacity;
                    //Main.EntitySpriteDraw(projectileTexture, drawPosition, null, afterimageColor, rotation, projectileTexture.Size() * 0.5f, Projectile.scale, SpriteEffects.None, 0);
                }
            }           

            return false;
        }

        public override void SetStaticDefaults()
        {
            ProjectileID.Sets.TrailingMode[Projectile.type] = 2;
            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 36;
        }
        //public override bool PreDraw(ref Color lightColor)
        //{
        //    Texture2D tex = Terraria.GameContent.TextureAssets.Projectile[Projectile.type].Value;
        //    Vector2 drawPos = Projectile.Center - Main.screenPosition + new Vector2(0f, Projectile.gfxOffY);
        //    Rectangle rectangle = new Rectangle(0, 0, tex.Width, tex.Height);
        //    Vector2 origin = tex.Size() / 2f;
        //    SpriteEffects spriteEffects = SpriteEffects.None;
        //    if (Projectile.spriteDirection == -1)
        //        spriteEffects = SpriteEffects.FlipHorizontally;

        //    Main.EntitySpriteDraw(tex, drawPos, new Microsoft.Xna.Framework.Rectangle?(rectangle), lightColor, Projectile.rotation, origin, Projectile.scale, spriteEffects, 0);

        //    // 添加紫色和蓝色混合的着色器特效
        //    GameShaders.Misc["CalamityMod:TrailStreak"].SetShaderTexture(ModContent.Request<Texture2D>("CalamityMod/ExtraTextures/Trails/FabstaffStreak"));
        //    Color blendColor = Color.Lerp(Color.Purple, Color.Blue, 0.5f);
        //    Lighting.AddLight(Projectile.Center + (Projectile.rotation - MathHelper.PiOver2).ToRotationVector2() * Projectile.height * 0.45f, blendColor.ToVector3() * 0.4f);

        //    return false;
        //}


    }
}
