﻿using CalamityMod;
using CalamityThrowingSpear.Global;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using CalamityMod.Particles;
using Terraria.DataStructures;
using CalamityMod.Items.Weapons.Melee;
using CalamityMod.Dusts;

namespace CalamityThrowingSpear.Weapons.NewWeapons.EAfterDog.ArkofTheDragonSoul
{
    public class ADSStar : ModProjectile
    {
        public List<Particle> Particles;
        private static readonly Dictionary<Type, int> LocalParticleTypes = new();
        public override void SetDefaults()
        {
            // 设置弹幕的基础属性
            Projectile.width = 11; // 弹幕宽度
            Projectile.height = 24; // 弹幕高度
            Projectile.friendly = true; // 对敌人有效
            Projectile.DamageType = DamageClass.Melee; // 近战伤害类型
            Projectile.penetrate = 1; // 穿透力为1，击中一个敌人就消失
            Projectile.timeLeft = 1800; // 弹幕存在时间为600帧
            Projectile.usesLocalNPCImmunity = true; // 弹幕使用本地无敌帧
            Projectile.localNPCHitCooldown = 14; // 无敌帧冷却时间为14帧
            Projectile.ignoreWater = true; // 弹幕不受水影响
            Projectile.arrow = true;
            Projectile.extraUpdates = 1;
            // 初始化本地粒子类型
            if (LocalParticleTypes.Count == 0)
            {
                LocalParticleTypes[typeof(BloomLineVFX)] = 1; // 示例值，需替换为实际值
                LocalParticleTypes[typeof(GenericSparkle)] = 2; // 示例值，需替换为实际值
            }
        }
        public void BootlegSpawnParticle(Particle particle)
        {
            if (!Main.dedServ)
            {
                Particles.Add(particle);

                // 使用本地字典查找类型
                if (LocalParticleTypes.TryGetValue(particle.GetType(), out int typeId))
                {
                    particle.Type = typeId;
                }
                else
                {
                    // 未找到类型时记录警告或处理异常
                    ModContent.GetInstance<Mod>().Logger.Warn($"Particle type not found for {particle.GetType().Name}");
                }
            }
        }
        public override void OnSpawn(IEntitySource source)
        {
            Projectile.velocity *= 0.4f;
            // 生成一个紫色或蓝色的冲击波特效
            Particle pulse = new DirectionalPulseRing(Projectile.Center, Projectile.velocity * 0.75f, Color.AliceBlue, new Vector2(1f, 2.5f), Projectile.rotation, 0.2f, 0.03f, 20);
            GeneralParticleHandler.SpawnParticle(pulse);
        }

        public override void AI()
        {
            Projectile.velocity *= 1.02f;

            // 初始化粒子列表
            if (Particles == null)
                Particles = new List<Particle>();

            // 添加高速旋转效果
            Projectile.rotation += 0.45f;

            // 前x帧不追踪，之后开始追踪敌人
            if (Projectile.ai[1] > 100)
            {
                NPC target = Projectile.Center.ClosestNPCAt(8800); // 查找范围内最近的敌人 
                if (target != null)
                {
                    Vector2 direction = (target.Center - Projectile.Center).SafeNormalize(Vector2.Zero);
                    Projectile.velocity = Vector2.Lerp(Projectile.velocity, direction * 22f, 0.15f); // 追踪速度为xf
                }
            }
            else
            {
                Projectile.velocity = Projectile.velocity.RotatedBy(-MathHelper.ToRadians(14));
                Projectile.ai[1]++;
            }



            // 计数器，用于控制特效释放频率
            int counter = (int)Projectile.ai[0];

            // 每5帧生成一次线条粒子特效
            if (counter % 5 == 0)
            {
                Vector2 previousStar = Projectile.Center - Projectile.velocity; // 假定为上一个位置
                Vector2 sizeVector = new Vector2(Projectile.width / 2, Projectile.height / 2);
                BloomLineVFX line = new BloomLineVFX(previousStar, Projectile.Center + sizeVector - previousStar, 0.8f, Color.MediumVioletRed * 0.75f, 20, true);
                BootlegSpawnParticle(line);
            }

            // 每20帧释放一圈规整的星星特效
            if (counter % 20 == 0)
            {
                Vector2 sizeVector = new Vector2(Projectile.width / 2, Projectile.height / 2);
                GenericSparkle star = new GenericSparkle(Projectile.Center + sizeVector, Vector2.Zero, Color.White, Color.Plum, Main.rand.NextFloat(1f, 1.5f), 20, 0f, 3f);
                BootlegSpawnParticle(star);
            }

            // 更新计数器
            Projectile.ai[0] += 1;





            if (Main.rand.NextBool(16))
            {
                Vector2 rotational = Vector2.UnitX.RotatedByRandom(1.5707963705062866).RotatedBy((double)Projectile.velocity.ToRotation(), default);
                int astralDust = Dust.NewDust(Projectile.position, Projectile.width, Projectile.height, ModContent.DustType<AstralOrange>(), Projectile.velocity.X * 0.5f, Projectile.velocity.Y * 0.5f, 150, default, 1f);
                Main.dust[astralDust].velocity = rotational * 0.66f;
                Main.dust[astralDust].position = Projectile.Center + rotational * 12f;
            }

            if (Main.rand.NextBool(48) && Main.netMode != NetmodeID.Server)
            {
                int starry = Gore.NewGore(Projectile.GetSource_FromAI(), Projectile.Center, new Vector2(Projectile.velocity.X * 0.2f, Projectile.velocity.Y * 0.2f), 16, 1f);
                Main.gore[starry].velocity *= 0.66f;
                Main.gore[starry].velocity += Projectile.velocity * 0.3f;
            }

            if (Projectile.ai[1] == 1f)
            {
                Projectile.light = 0.9f;
                if (Main.rand.NextBool(10))
                    Dust.NewDust(Projectile.position, Projectile.width, Projectile.height, ModContent.DustType<AstralOrange>(), Projectile.velocity.X * 0.5f, Projectile.velocity.Y * 0.5f, 150, default, 1f);
                if (Main.rand.NextBool(20) && Main.netMode != NetmodeID.Server)
                    Gore.NewGore(Projectile.GetSource_FromAI(), Projectile.position, new Vector2(Projectile.velocity.X * 0.2f, Projectile.velocity.Y * 0.2f), Main.rand.Next(16, 18), 1f);
            }
        }

        //public void BootlegSpawnParticle(Particle particle)
        //{
        //    if (!Main.dedServ)
        //    {
        //        Particles.Add(particle);
        //        particle.Type = GeneralParticleHandler.particleTypes[particle.GetType()];
        //    }
        //}

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {

        }



        public override Color? GetAlpha(Color lightColor) => new Color(200, 100, 250, Projectile.alpha);

        public override void OnKill(int timeLeft)
        {
            if (Projectile.ai[0] == 1f)
                return;

            Projectile.position.X = Projectile.position.X + Projectile.width / 2;
            Projectile.position.Y = Projectile.position.Y + Projectile.height / 2;
            Projectile.width = 36;
            Projectile.height = 36;
            Projectile.position.X = Projectile.position.X - Projectile.width / 2;
            Projectile.position.Y = Projectile.position.Y - Projectile.height / 2;
            for (int i = 0; i < 5; i++)
            {
                int starryDust = Dust.NewDust(Projectile.position, Projectile.width, Projectile.height, ModContent.DustType<AstralOrange>(), 0f, 0f, 100, default, 1.2f);
                Main.dust[starryDust].velocity *= 3f;
                if (Main.rand.NextBool())
                {
                    Main.dust[starryDust].scale = 0.5f;
                    Main.dust[starryDust].fadeIn = 1f + Main.rand.Next(10) * 0.1f;
                }
            }
            for (int j = 0; j < 5; j++)
            {
                int starryDust2 = Dust.NewDust(Projectile.position, Projectile.width, Projectile.height, ModContent.DustType<AstralOrange>(), 0f, 0f, 100, default, 1.7f);
                Main.dust[starryDust2].noGravity = true;
                Main.dust[starryDust2].velocity *= 5f;
                starryDust2 = Dust.NewDust(Projectile.position, Projectile.width, Projectile.height, ModContent.DustType<AstralOrange>(), 0f, 0f, 100, default, 1f);
                Main.dust[starryDust2].velocity *= 2f;
            }
            if (Main.netMode != NetmodeID.Server)
            {
                for (int k = 0; k < 3; k++)
                    Gore.NewGore(Projectile.GetSource_Death(), Projectile.position, new Vector2(Projectile.velocity.X * 0.05f, Projectile.velocity.Y * 0.05f), Main.rand.Next(16, 18), 1f);
            }





            // 生成更多方向的多层粒子效果
            int layers = 2; // 设置两层
            int pointsPerLayer = 6; // 每层6个方向

            for (int layer = 0; layer < layers; layer++)
            {
                float radiusMultiplier = 1f + layer * 0.5f; // 每层粒子半径增大
                for (int i = 0; i < pointsPerLayer; i++)
                {
                    float angle = MathHelper.TwoPi * i / pointsPerLayer;
                    Vector2 scatterDirection = Projectile.velocity.RotatedBy(angle) * radiusMultiplier;

                    // 定义复杂的宇宙配色粒子
                    Particle pulse = new DirectionalPulseRing(
                        Projectile.Center,
                        scatterDirection,
                        Color.Lerp(Color.Purple, Color.Blue, Main.rand.NextFloat()),
                        new Vector2(1f, 2.5f).RotatedBy(Projectile.rotation + MathHelper.PiOver2), // 调整比例与弹幕垂直
                        Projectile.rotation, // 保持与弹幕一致的旋转
                        0.2f, // 粒子透明度衰减
                        0.1f, // 粒子每帧的扩展速度
                        30 + layer * 10); // 每层粒子存活时间不同

                    // 生成粒子
                    GeneralParticleHandler.SpawnParticle(pulse);
                }
            }
        }
        public override void SetStaticDefaults()
        {
            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 10;
            ProjectileID.Sets.TrailingMode[Projectile.type] = 1;
        }
        public override bool PreDraw(ref Color lightColor)
        {
            Projectile.DrawStarTrail(Color.Coral, Color.White);
            CalamityUtils.DrawAfterimagesCentered(Projectile, ProjectileID.Sets.TrailingMode[Projectile.type], lightColor, 2);
            return false;
        }

    }
}
