﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using CalamityMod;
//using CalamityMod.Particles;
//using CalamityMod.Sounds;
//using CalamityThrowingSpear.Weapons.ChangedWeapons.EAfterDog.DragonRageC;
//using Microsoft.Xna.Framework;
//using Microsoft.Xna.Framework.Graphics;
//using Terraria;
//using Terraria.Audio;
//using Terraria.ID;
//using Terraria.ModLoader;
//using static System.Security.Cryptography.ECCurve;
//using static CalamityMod.CalamityUtils;
//using System;
//using System.IO;
//using CalamityMod.Items.Weapons.Melee;
//using CalamityMod.Particles;
//using CalamityMod.Sounds;
//using Microsoft.Xna.Framework;
//using Microsoft.Xna.Framework.Graphics;
//using Terraria;
//using Terraria.Audio;
//using Terraria.ID;
//using Terraria.ModLoader;
//using static CalamityMod.CalamityUtils;
//using static Terraria.ModLoader.ModContent;

//namespace CalamityThrowingSpear.Weapons.NewWeapons.DPreDog.ElementalArkJav
//{
//    public class ElementalArkJavBlade05 : ModProjectile
//    {
//        private Vector2 startPoint;
//        private Vector2 controlPoint;
//        private Vector2 endPoint;
//        private float progress;
//        public int Time = 0;

//        public override void SetStaticDefaults()
//        {
//            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 8;
//            ProjectileID.Sets.TrailingMode[Projectile.type] = 2;
//        }

//        public override bool PreDraw(ref Color lightColor)
//        {
//            // 绘制弹幕的残影效果
//            CalamityUtils.DrawAfterimagesCentered(Projectile, ProjectileID.Sets.TrailingMode[Projectile.type], lightColor, 1);

//            // 绘制星空链条粒子效果
//            if (Particles != null)
//            {
//                Main.spriteBatch.EnterShaderRegion(BlendState.Additive);
//                foreach (Particle particle in Particles)
//                    particle.CustomDraw(Main.spriteBatch);
//                Main.spriteBatch.ExitShaderRegion();
//            }

//            return false;
//        }

//        public List<Particle> Particles;

//        public override void SetDefaults()
//        {
//            Projectile.width = 14;
//            Projectile.height = 14;
//            Projectile.friendly = true;
//            Projectile.hostile = false;
//            Projectile.DamageType = DamageClass.Melee;
//            Projectile.penetrate = -1;
//            Projectile.timeLeft = 120;
//            Projectile.light = 0.5f;
//            Projectile.ignoreWater = true;
//            Projectile.tileCollide = true;
//            Projectile.extraUpdates = 1;
//            Projectile.usesLocalNPCImmunity = true;
//            Projectile.localNPCHitCooldown = 14;
//        }


//        // 定义 anticipation 和 thrust 为 CurveSegment 类型的静态实例
//        public CurveSegment anticipation = new CurveSegment(EasingType.SineBump, 0f, 0.2f, -0.1f); // 预备阶段，快速过渡
//        public CurveSegment thrust = new CurveSegment(EasingType.PolyOut, 0.3f, 0.2f, 3f, 3); // 撕裂阶段，保持较长的时间
//        const float MaxTime = 70;
//        const float SnapTime = 25f;
//        const float HoldTime = 15f;

//        public float SnapTimer => MaxTime - Projectile.timeLeft;
//        public float HoldTimer => MaxTime - Projectile.timeLeft - SnapTime;
//        public float SnapProgress => MathHelper.Clamp(SnapTimer / SnapTime, 0, 1);

//        // 定义 ThrustDisplaceRatio 方法
//        internal float ThrustDisplaceRatio() => PiecewiseAnimation(SnapProgress, new CurveSegment[] { anticipation, thrust });

//        public override void AI()
//        {
//            if (Projectile.ai[0] == 0) // 初始化位置
//            {
//                startPoint = Projectile.position;
//                endPoint = Main.MouseWorld;
//                controlPoint = (startPoint + endPoint) / 2 + new Vector2(0, 150); // 下曲线
//                Projectile.ai[0] = 1;
//            }

//            // 计算贝塞尔曲线位置
//            progress += 1f / Projectile.timeLeft;
//            if (progress >= 1f)
//            {
//                Projectile.Kill();
//                return;
//            }
//            Vector2 bezierPosition = Vector2.Lerp(Vector2.Lerp(startPoint, controlPoint, progress), Vector2.Lerp(controlPoint, endPoint, progress), progress);
//            Projectile.Center = bezierPosition;

//            // 每隔3帧生成粒子效果
//            if (Main.rand.NextBool(3))
//            {
//                Vector2 particlePosition = Projectile.Center + Main.rand.NextVector2Circular(10f, 10f);
//                Color particleColor = Main.rand.NextBool() ? Color.OrangeRed : Main.rand.NextBool() ? Color.White : Color.Orange;
//                float particleScale = Main.rand.NextFloat(0.2f, 0.5f);

//                // 随机选择粒子生成方式并生成粒子
//                int particleType = Main.rand.Next(3);
//                switch (particleType)
//                {
//                    case 0:
//                        GeneralParticleHandler.SpawnParticle(new StrongBloom(particlePosition, Vector2.UnitX.RotatedByRandom(MathHelper.TwoPi) * Main.rand.NextFloat(2f, 4f), particleColor, particleScale, Main.rand.Next(20) + 10));
//                        break;
//                    case 1:
//                        GeneralParticleHandler.SpawnParticle(new GenericBloom(particlePosition, Main.rand.NextVector2Circular(3f, 3f), particleColor, particleScale, Main.rand.Next(20) + 10));
//                        break;
//                    case 2:
//                        GeneralParticleHandler.SpawnParticle(new CritSpark(particlePosition, -Projectile.velocity * Main.rand.NextFloat(0.5f, 1.5f), Color.White, particleColor, particleScale * 5f, Main.rand.Next(20) + 10, 0.1f, 3));
//                        break;
//                }
//            }

//            // 旋转和光效
//            Projectile.rotation += 0.2f;
//            Lighting.AddLight(Projectile.Center, Color.DeepSkyBlue.ToVector3() * 0.75f);
//            Time++;
//        }



//        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
//        {
//            int slashCount = Main.rand.Next(2, 5);
//            for (int i = 0; i < slashCount; i++)
//            {
//                Vector2 randomDirection = Vector2.UnitX.RotatedByRandom(MathHelper.TwoPi);
//                int slashID = ModContent.ProjectileType<OrangeSLASH>();
//                Projectile.NewProjectile(Projectile.GetSource_FromThis(), target.Center, randomDirection, slashID, Projectile.damage, Projectile.knockBack, Projectile.owner);
//            }
//            SoundEngine.PlaySound(CommonCalamitySounds.SwiftSliceSound with { Volume = 0.5f }, Projectile.Center);
//        }
//        public override void OnKill(int timeLeft)
//        {
//            if (Particles == null)
//                Particles = new List<Particle>();

//            Player player = Main.player[Projectile.owner];
//            Vector2 startPosition = Projectile.Center;
//            Vector2 endPosition = player.Center;
//            Vector2 sizeVector = (endPosition - startPosition).SafeNormalize(Vector2.Zero) * 300f;

//            Particles.Clear();
//            float constellationColorHue = Main.rand.NextFloat();
//            Vector2 previousStar = startPosition;
//            Vector2 offset;

//            for (float i = 0; i < 1f; i += Main.rand.NextFloat(0.2f, 0.5f))
//            {
//                constellationColorHue = (constellationColorHue + 0.16f) % 1f;
//                Color constellationColor = Main.hslToRgb(constellationColorHue, 1f, 0.8f);
//                offset = Main.rand.NextFloat(-50f, 50f) * sizeVector.RotatedBy(MathHelper.PiOver2);

//                Particle star = new GenericSparkle(startPosition + sizeVector * i + offset, Vector2.Zero, Color.White, constellationColor, Main.rand.NextFloat(1f, 1.5f), 60, 0f, 3f);
//                Particles.Add(star);

//                Particle line = new BloomLineVFX(previousStar, startPosition + sizeVector * i + offset - previousStar, 0.8f, constellationColor * 0.75f, 60, true);
//                Particles.Add(line);

//                previousStar = startPosition + sizeVector * i + offset;
//            }

//            Particle finalStar = new GenericSparkle(endPosition, Vector2.Zero, Color.White, Color.Cyan, Main.rand.NextFloat(1f, 1.5f), 60, 0f, 3f);
//            Particles.Add(finalStar);
//            Particle finalLine = new BloomLineVFX(previousStar, endPosition - previousStar, 0.8f, Color.Cyan * 0.75f, 60, true);
//            Particles.Add(finalLine);














//        }




//    }
//}
