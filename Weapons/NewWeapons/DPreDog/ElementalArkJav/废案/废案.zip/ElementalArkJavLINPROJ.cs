﻿//using Microsoft.Xna.Framework;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Terraria.ID;
//using Terraria.ModLoader;
//using Terraria;
//using CalamityMod.Projectiles.Melee;
//using CalamityMod;
//using System;
//using System.IO;
//using CalamityMod.Items.Weapons.Melee;
//using CalamityMod.Projectiles.BaseProjectiles;
//using Microsoft.Xna.Framework;
//using Microsoft.Xna.Framework.Graphics;
//using Terraria;
//using Terraria.Audio;
//using Terraria.Graphics.Shaders;
//using Terraria.ID;
//using Terraria.Localization;
//using Terraria.ModLoader;

//namespace CalamityThrowingSpear.Weapons.NewWeapons.DPreDog.ElementalArkJav
//{
//    public class ElementalArkJavLINPROJ : BaseIdleHoldoutProjectile
//    {
//        public enum SwingState : byte
//        {
//            Default, // 默认状态
//            Swinging, // 挥动状态
//            Channeling, // 蓄力状态
//            Spinning // 旋转状态
//        }

//        public int Direction = 1; // 武器的方向，1表示向右，-1表示向左
//        public SwingState CurrentState; // 当前的挥动状态
//        public ref float ChargeTime => ref Projectile.ai[0]; // 蓄力时间
//        public ref float GeneralTime => ref Projectile.ai[1]; // 通用计时器
//        public ref float PostSwingRepositionDelay => ref Projectile.localAI[0]; // 挥动后的重新定位延迟
//        public ref bool RMBChannel => ref (Owner.HeldItem.ModItem as ElementalArkJavLIN).RMBchannel; // 右键按下的状态
//        public bool LMBUse => Owner.altFunctionUse != 2 && !RMBChannel && Owner.itemAnimation > 0; // 左键使用条件
//        public ref float ChargePower => ref Projectile.localAI[1]; // 蓄力的力量值

//        public override int AssociatedItemID => throw new NotImplementedException();

//        public override int IntendedProjectileType => throw new NotImplementedException();

//        public const int MaxChargeTime = 90; // 最大蓄力时间

//        public override void SetStaticDefaults()
//        {
//            // 设置静态默认值
//            ProjectileID.Sets.TrailingMode[Projectile.type] = 2; // 设置弹幕的拖尾模式
//            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 3; // 设置拖尾的长度
//        }

//        public override void SetDefaults()
//        {
//            // 设置弹幕的默认属性
//            Projectile.width = Projectile.height = 70; // 弹幕的宽度和高度
//            Projectile.friendly = true; // 弹幕对敌人友好
//            Projectile.DamageType = DamageClass.Melee; // 弹幕的伤害类型为近战
//            Projectile.tileCollide = false; // 不与方块碰撞
//            Projectile.penetrate = -1; // 无限次穿透
//            Projectile.timeLeft = 90000; // 弹幕存活时间
//            Projectile.usesLocalNPCImmunity = true; // 使用本地NPC无敌帧
//            Projectile.localNPCHitCooldown = 12; // 无敌帧冷却时间
//            Projectile.noEnchantmentVisuals = true; // 没有附魔效果
//        }

//        public override void SendExtraAI(BinaryWriter writer)
//        {
//            writer.Write(Direction);
//            writer.Write(PostSwingRepositionDelay);
//            writer.Write(ChargePower);
//            writer.Write((byte)CurrentState);
//        }

//        public override void ReceiveExtraAI(BinaryReader reader)
//        {
//            Direction = reader.ReadInt32();
//            PostSwingRepositionDelay = reader.ReadSingle();
//            ChargePower = reader.ReadSingle();
//            CurrentState = (SwingState)reader.ReadByte();
//        }
//        public override void SafeAI()
//        {
//            // Handle right click behaviors.
//            if (Main.myPlayer == Projectile.owner)
//                Owner.Calamity().rightClickListener = true;

//            if (!Owner.Calamity().mouseRight)
//                RMBChannel = false;
//            else
//                RMBChannel = true;

//            // Initialize the animation max time if necessary.
//            if (Owner.itemAnimationMax == 0)
//                Owner.itemAnimationMax = (int)(Owner.ActiveItem().useAnimation * Owner.GetAttackSpeed<MeleeDamageClass>());

//            // Decide the current phase state of the blade.
//            DecideCurrentState();

//            // Glue the sword to its owner.
//            Projectile.position = Owner.RotatedRelativePoint(Owner.MountedCenter, true) - Projectile.Size / 2f;

//            // Use the direction of the owner when not spinning.
//            if (CurrentState != SwingState.Spinning)
//                Direction = Owner.direction;

//            float swingCompletion = Owner.itemAnimation / (float)Owner.itemAnimationMax;
//            float swingSpeedInterpolant = Utils.GetLerpValue(1f, 0.8f, swingCompletion, true) * Utils.GetLerpValue(-0.11f, 0.12f, swingCompletion, true);
//            float swingInterpolant = (float)Math.Sin(Math.Pow(swingCompletion, 1.15) * MathHelper.TwoPi);
//            if (swingInterpolant < 0f)
//            {
//                swingInterpolant = -(float)Math.Pow(-swingInterpolant, 0.9);
//                swingInterpolant = MathHelper.Lerp(swingInterpolant, -1f, 0.7f);
//            }
//            else
//            {
//                swingInterpolant = (float)Math.Pow(swingInterpolant, 0.9);
//                swingInterpolant = MathHelper.Lerp(swingInterpolant, 1f, 0.7f);
//            }

//            float baseRotation = swingInterpolant * Direction * 0.96f;

//            // Reset the owner's rotation.
//            Owner.fullRotation = 0f;

//            // Do a spin dash if a swing is done with full power.
//            if (CurrentState == SwingState.Spinning)
//            {
//                swingSpeedInterpolant = 1f;
//                baseRotation = MathHelper.WrapAngle(swingCompletion * Direction * MathHelper.Pi * -3f);
//                Owner.fullRotation = baseRotation;
//                Owner.fullRotationOrigin = Owner.Center - Owner.position;

//                // Emit fire dust.
//                for (int i = 0; i < 4; i++)
//                {
//                    Vector2 dustSpawnPosition = Projectile.Center + (Projectile.rotation - MathHelper.PiOver4).ToRotationVector2() * Main.rand.NextFloat(Projectile.width) + Main.rand.NextVector2Circular(6f, 6f);
//                    Vector2 dustVelocity = (Projectile.rotation - MathHelper.PiOver4).ToRotationVector2() * Main.rand.NextFloat(6f) + Main.rand.NextVector2Circular(2.4f, 2.4f);

//                    Dust fire = Dust.NewDustPerfect(dustSpawnPosition, 6, dustVelocity);
//                    fire.scale = 1.7f;
//                    fire.noGravity = true;
//                }

//                // Release flames.
//                if (Main.myPlayer == Projectile.owner && GeneralTime % 6f == 5f)
//                    Projectile.NewProjectile(Projectile.GetSource_FromThis(), Projectile.Center, Main.rand.NextVector2CircularEdge(8f, 8f), ModContent.ProjectileType<OathswordFlame>(), Projectile.damage / 2, Projectile.knockBack * 0.5f, Projectile.owner);

//                if (Main.myPlayer == Projectile.owner)
//                {
//                    Owner.velocity = Vector2.Lerp(Owner.velocity, Owner.SafeDirectionTo(Main.MouseWorld) * 16f, 0.125f);
//                    NetMessage.SendData(MessageID.PlayerControls, -1, -1, null, Main.myPlayer);
//                }

//                // Stop charging once the item animation has completed.
//                if (Owner.itemAnimation <= 1)
//                {
//                    ChargePower = 0f;
//                    CurrentState = 0f;
//                }
//            }

//            // Hold the blade upwards if not firing.
//            if (CurrentState == SwingState.Default)
//            {
//                Projectile.Opacity = 0f;

//                if (PostSwingRepositionDelay > 0f)
//                    PostSwingRepositionDelay--;
//                else
//                    baseRotation = (MathHelper.PiOver2 + 0.36f) * -Direction;

//                // Disable afterimages.
//                Projectile.oldPos = new Vector2[Projectile.oldPos.Length];
//            }
//            else
//            {
//                PostSwingRepositionDelay = PostSwingRepositionDelay == -1f ? 0f : 12f;

//                // See the Bladecrest Oathsword Projectile code.
//                Projectile.Opacity = 1f;
//            }

//            // Raise the blade and do charge effects upwards if channeling.
//            float horizontalBladeOffset = -4f;
//            float chargeInterpolant = Utils.GetLerpValue(0f, 65f, ChargeTime, true);
//            if (CurrentState == SwingState.Channeling)
//            {
//                baseRotation = MathHelper.PiOver2 * -Direction;
//                horizontalBladeOffset = MathHelper.Lerp(horizontalBladeOffset, 6f, (float)Math.Pow(chargeInterpolant, 0.3));
//                if (Owner.itemAnimation < 2)
//                    Owner.itemAnimation = 2;
//                PostSwingRepositionDelay = -1f;

//                ChargePower = MathHelper.Clamp(ChargePower + 1f, 0f, MaxChargeTime);

//                // Disable afterimages.
//                Projectile.oldPos = new Vector2[Projectile.oldPos.Length];

//                ChargeTime++;
//            }
//            else
//                ChargeTime = 0f;

//            float idealRotation = baseRotation;
//            Owner.itemRotation = idealRotation;

//            idealRotation += MathHelper.PiOver4;
//            if (Direction == -1)
//                idealRotation += MathHelper.Pi;

//            // Define rotation.
//            Projectile.rotation = Projectile.rotation.AngleTowards(idealRotation, swingSpeedInterpolant * 0.45f).AngleLerp(idealRotation, swingSpeedInterpolant * 0.2f);

//            // Decide how far out the blade should go.
//            float bladeOffsetFactor = 0.5f + chargeInterpolant * 0.3f;
//            if (chargeInterpolant <= 0f)
//                bladeOffsetFactor += Utils.GetLerpValue(0.5f, 0.7f, swingCompletion, true) * Utils.GetLerpValue(1f, 0.7f, swingCompletion, true) * 0.45f;

//            // Offset the blade so that the handle is attached to the owner's hand.
//            Vector2 bladeOffset = (Projectile.rotation - MathHelper.PiOver4).ToRotationVector2() * Projectile.width * bladeOffsetFactor;
//            if (Owner.itemAnimation <= 0 || chargeInterpolant > 0f)
//                bladeOffset += new Vector2(Direction * horizontalBladeOffset, 8f).RotatedBy(Owner.fullRotation) * (1f - PostSwingRepositionDelay / 12f);
//            Projectile.position += bladeOffset;

//            // Create charge dust.
//            if (CurrentState == SwingState.Channeling)
//            {
//                int chargeDustCount = (int)Math.Round(MathHelper.Lerp(1f, 3f, ChargePower / MaxChargeTime));
//                if (ChargePower >= MaxChargeTime)
//                    chargeDustCount = 0;

//                for (int i = 0; i < chargeDustCount; i++)
//                {
//                    Vector2 dustSpawnPosition = Projectile.Center + (Projectile.rotation - MathHelper.PiOver4).ToRotationVector2() * Main.rand.NextFloat(Projectile.width) + Main.rand.NextVector2Circular(6f, 6f);
//                    Vector2 dustVelocity = bladeOffset.SafeNormalize(Vector2.Zero) * Main.rand.NextFloat(6f) + Main.rand.NextVector2Circular(2.4f, 2.4f);

//                    Dust dust = Dust.NewDustPerfect(dustSpawnPosition, 267, dustVelocity);
//                    dust.color = Main.rand.NextBool(4) ? Color.Purple : Color.Red;
//                    dust.scale = Main.rand.NextFloat(0.85f, 1.2f);
//                    dust.noGravity = true;
//                }

//                // Create a burst of charge dust before becoming fully charged.
//                if (ChargePower == MaxChargeTime - 1f)
//                {
//                    SoundEngine.PlaySound(SoundID.Item74, Projectile.Center);
//                    for (int i = 0; i < 30; i++)
//                    {
//                        Vector2 dustSpawnPosition = Projectile.Center;
//                        Vector2 dustVelocity = (MathHelper.TwoPi * i / 30f).ToRotationVector2() * 5f;
//                        Dust dust = Dust.NewDustPerfect(dustSpawnPosition, 267, dustVelocity);
//                        dust.color = Color.Violet;
//                        dust.scale = 1.4f;
//                        dust.noGravity = true;
//                    }
//                }
//            }

//            GeneralTime++;
//        }

//        public void DecideCurrentState()
//        {
//            // Reset the state of the weapon if the player stops using it. This cannot reset a dash.
//            if ((Owner.itemAnimation <= 0 || (!RMBChannel && CurrentState == SwingState.Channeling)) && CurrentState != SwingState.Spinning)
//            {
//                Owner.itemAnimation = 0;
//                CurrentState = SwingState.Default;
//            }

//            // Switch to the swing state as necessary. This cannot happen while channeling or spinning.
//            if (CurrentState == 0f && !RMBChannel && Owner.itemAnimation > 0 && ChargePower < MaxChargeTime)
//                CurrentState = SwingState.Swinging;

//            // Switch to the channel state as necessary. This cannot happen while swinging or spinning.
//            if ((CurrentState == SwingState.Default || CurrentState == SwingState.Swinging) && RMBChannel)
//                CurrentState = SwingState.Channeling;

//            // Switch to the spinning charge state. This can only be done while in the default state.
//            if (CurrentState == 0f && Owner.itemAnimation > 0 && ChargePower >= MaxChargeTime)
//            {
//                Owner.fallStart = (int)(Owner.position.Y / 16f);

//                if (CurrentState != SwingState.Spinning)
//                {
//                    SoundEngine.PlaySound(SoundID.DD2_BookStaffCast, Owner.Center);
//                    CurrentState = SwingState.Spinning;
//                    Projectile.netUpdate = true;
//                }
//            }
//        }

//        public override bool PreDraw(ref Color lightColor)
//        {
//            if (Projectile.Opacity <= 0f)
//                return false;

//            CalamityUtils.DrawAfterimagesCentered(Projectile, 2, lightColor);

//            Main.spriteBatch.EnterShaderRegion();
//            GameShaders.Misc["CalamityMod:BasicTint"].UseColor(Main.hslToRgb(0.95f, 0.85f, 0.5f));
//            GameShaders.Misc["CalamityMod:BasicTint"].UseOpacity(0f);
//            if (ChargePower >= MaxChargeTime)
//                GameShaders.Misc["CalamityMod:BasicTint"].UseOpacity(0.7f - ((Main.GlobalTimeWrappedHourly * (int)(MaxChargeTime * 0.5f)) % (MaxChargeTime * 0.5f) / MaxChargeTime));
//            GameShaders.Misc["CalamityMod:BasicTint"].Apply();

//            var texture = ModContent.Request<Texture2D>("CalamityMod/Items/Weapons/Melee/OldLordClaymore").Value;

//            Main.EntitySpriteDraw(texture, Projectile.Center - Main.screenPosition, null, Projectile.GetAlpha(lightColor), Projectile.rotation, Projectile.Size / 2f, Projectile.scale, Projectile.spriteDirection == -1 ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 0);
//            Main.spriteBatch.ExitShaderRegion();

//            return false;
//        }

//        public override void ModifyDamageHitbox(ref Rectangle hitbox)
//        {
//            if (CurrentState == SwingState.Spinning)
//                hitbox = new Rectangle((int)Owner.position.X - 35, (int)Owner.position.Y - 35, 102, 118);
//        }

//        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
//        {
//            ItemLoader.OnHitNPC(Owner.ActiveItem(), Owner, target, hit, damageDone);
//            NPCLoader.OnHitByItem(target, Owner, Owner.ActiveItem(), hit, damageDone);
//            PlayerLoader.OnHitNPC(Owner, target, hit, damageDone);

//            if (CurrentState == SwingState.Spinning)
//            {
//                Owner.immuneNoBlink = true;
//                Owner.immune = true;
//                Owner.immuneTime = 12;
//                for (int k = 0; k < Owner.hurtCooldowns.Length; k++)
//                    Owner.hurtCooldowns[k] = Owner.immuneTime;
//            }
//        }

//        public override void OnKill(int timeLeft) => Owner.fullRotation = 0f;
//    }
//}
