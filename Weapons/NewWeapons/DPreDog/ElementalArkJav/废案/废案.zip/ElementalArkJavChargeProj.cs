﻿//using CalamityMod.Projectiles.BaseProjectiles;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Terraria.ID;
//using Terraria.ModLoader;
//using Terraria;
//using Microsoft.Xna.Framework;

////namespace CalamityThrowingSpear.Weapons.NewWeapons.DPreDog.ElementalArkJav
////{
////    public class ElementalArkJavChargeProj : BaseIdleHoldoutProjectile
////    {
////        public override int AssociatedItemID => ModContent.ItemType<ElementalArkJav>();

////        public override int IntendedProjectileType => throw new NotImplementedException();

////        private int chargePower = 0;
////        private const int maxChargeTime = 120;
////        private bool isCharged = false;

////        public override void SafeAI()
////        {
////            Player player = Main.player[Projectile.owner];

////            if (player.controlUseTile) // 检测右键
////            {
////                chargePower++;
////                if (chargePower >= maxChargeTime)
////                {
////                    isCharged = true;
////                    Main.NewText("充能已完成！");
////                    for (int i = 0; i < 20; i++)
////                    {
////                        Vector2 dustPos = Projectile.Center + Main.rand.NextVector2Circular(50f, 50f);
////                        Dust dust = Dust.NewDustPerfect(dustPos, DustID.Torch, Vector2.Zero);
////                        dust.color = Color.Orange;
////                    }
////                }
////            }
////            else if (isCharged && player.controlUseItem) // 松开右键并按左键发射特殊攻击
////            {
////                Projectile.NewProjectile(Projectile.GetSource_FromThis(), Projectile.Center, Projectile.velocity * 2,
////                    ModContent.ProjectileType<ElementalArkJavSUPERPROJ>(), Projectile.damage * 2, Projectile.knockBack, player.whoAmI);
////                isCharged = false;
////                chargePower = 0; // 重置充能
////            }
////        }
////    }
////}




//using CalamityMod.Projectiles.BaseProjectiles;
//using Microsoft.Xna.Framework;
//using Terraria;
//using Terraria.ID;
//using Terraria.ModLoader;

//namespace CalamityThrowingSpear.Weapons.NewWeapons.DPreDog.ElementalArkJav
//{
//    public class ElementalArkJavChargeProj : BaseIdleHoldoutProjectile
//    {
//        public override int AssociatedItemID => ModContent.ItemType<ElementalArkJav>();

//        public override int IntendedProjectileType => throw new NotImplementedException();

//        private int chargePower = 0;
//        private const int maxChargeTime = 120;
//        private bool isCharged = false;

//        public override void SafeAI()
//        {
//            Player player = Main.player[Projectile.owner];

//            if (player.controlUseTile) // 检测右键
//            {
//                chargePower++;
//                if (chargePower >= maxChargeTime)
//                {
//                    isCharged = true;
//                    Main.NewText("充能已完成！");
//                    for (int i = 0; i < 20; i++)
//                    {
//                        Vector2 dustPos = Projectile.Center + Main.rand.NextVector2Circular(50f, 50f);
//                        Dust dust = Dust.NewDustPerfect(dustPos, DustID.Torch, Vector2.Zero);
//                        dust.color = Color.Orange;
//                    }
//                }
//            }
//            else if (isCharged && player.controlUseItem) // 松开右键并按左键发射特殊攻击
//            {
//                Projectile.NewProjectile(Projectile.GetSource_FromThis(), Projectile.Center, Projectile.velocity * 2,
//                    ModContent.ProjectileType<ElementalArkJavSUPERPROJ>(), Projectile.damage * 2, Projectile.knockBack, player.whoAmI);
//                isCharged = false;
//                chargePower = 0; // 重置充能
//            }
//        }
//    }
//}
