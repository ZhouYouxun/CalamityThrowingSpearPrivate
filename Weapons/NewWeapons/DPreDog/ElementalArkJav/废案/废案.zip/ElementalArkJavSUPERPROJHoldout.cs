﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Terraria;
//using Terraria.ModLoader;
//using Microsoft.Xna.Framework;
//using System;
//using CalamityMod.Projectiles.Melee;

//namespace CalamityThrowingSpear.Weapons.NewWeapons.DPreDog.ElementalArkJav
//{
//    public class ElementalArkJavSUPERPROJHoldout : ModProjectile
//    {
//        public Player Owner => Main.player[Projectile.owner];
//        public ref float Time => ref Projectile.ai[0];
//        public const float ChargeTime = 60f; // 1秒的蓄力时间 (60帧)

//        public override void SetDefaults()
//        {
//            Projectile.width = 114;
//            Projectile.height = 114;
//            Projectile.friendly = false;
//            Projectile.tileCollide = false;
//            Projectile.ignoreWater = true;
//            Projectile.timeLeft = (int)ChargeTime + 10; // 多给一点时间避免提前消失
//        }

//        public override void AI()
//        {
//            UpdatePlayerVisuals();
//            if (Time >= ChargeTime)
//            {
//                ShootProjectile();
//                Projectile.Kill(); // 完成充能后消失
//            }
//            Time++;

//            // 如果玩家中止充能，取消弹幕
//            if (Main.mouseRightRelease && Time < ChargeTime)
//                Projectile.Kill();
//        }

//        private void UpdatePlayerVisuals()
//        {
//            Projectile.Center = Owner.RotatedRelativePoint(Owner.MountedCenter, true);
//            Projectile.rotation = Projectile.AngleTo(Main.MouseWorld);
//            Projectile.velocity = Projectile.rotation.ToRotationVector2();
//            Projectile.Center += Projectile.rotation.ToRotationVector2() * 30f;
//            Projectile.direction = Projectile.spriteDirection = (Math.Cos(Projectile.rotation) > 0).ToDirectionInt();

//            Owner.ChangeDir(Projectile.direction);
//            Owner.heldProj = Projectile.whoAmI;
//            Owner.itemTime = 2;
//            Owner.itemAnimation = 2;
//            Owner.itemRotation = Projectile.rotation;
//        }

//        private void ShootProjectile()
//        {
//            if (Main.myPlayer != Projectile.owner)
//                return;

//            Vector2 shootVelocity = Projectile.velocity * 16f; // 设置射出速度
//            Projectile.NewProjectile(Projectile.GetSource_FromThis(), Projectile.Center, shootVelocity,
//                ModContent.ProjectileType<ElementalArkJavSUPERPROJ>(), Owner.GetWeaponDamage(Owner.HeldItem), Projectile.knockBack, Projectile.owner);
//        }
//    }
//}
