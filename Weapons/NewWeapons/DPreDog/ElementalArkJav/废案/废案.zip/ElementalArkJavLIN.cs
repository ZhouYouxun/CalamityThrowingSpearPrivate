﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Terraria;
//using Terraria.ID;
//using Terraria.ModLoader;
//using Microsoft.Xna.Framework;
//using CalamityThrowingSpear.Weapons.NewWeapons.DPreDog.ElementalArkJav;

//namespace CalamityThrowingSpear.Weapons.NewWeapons.DPreDog.ElementalArkJav
//{
//    public class ElementalArkJavLIN : ModItem
//    {
//        public bool RMBchannel = false; // 是否按住右键的状态

//        public override void SetDefaults()
//        {
//            // 设置物品的默认属性
//            Item.width = 70; // 武器宽度
//            Item.height = 70; // 武器高度
//            Item.damage = 60; // 武器伤害
//            Item.DamageType = DamageClass.Melee; // 武器伤害类型为近战
//            Item.useAnimation = 34; // 使用动画的时间
//            Item.useTime = 34; // 使用时间
//            Item.channel = true; // 允许按住右键蓄力
//            Item.useStyle = ItemUseStyleID.Swing; // 使用动作为挥砍
//            Item.useTurn = true; // 使用时允许转身
//            Item.knockBack = 7f; // 击退值
//            Item.UseSound = SoundID.Item1; // 使用时的声音
//            Item.autoReuse = true; // 自动重复使用
//            Item.noUseGraphic = true; // 使用时不显示图形
//            Item.value = Item.sellPrice(silver: 10); // 物品的售价
//            Item.rare = ItemRarityID.Orange; // 物品稀有度
//        }

//        public override bool AltFunctionUse(Player player) => true; // 允许右键使用武器

//        public override bool? CanHitNPC(Player player, NPC target) => false; // 防止普通攻击时击中NPC

//        public override bool CanHitPvp(Player player, Player target) => false; // 防止PVP时攻击其他玩家
//    }
//}