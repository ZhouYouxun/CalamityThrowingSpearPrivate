﻿using CalamityMod;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using Microsoft.Xna.Framework;



namespace CalamityThrowingSpear.Weapons.NewWeapons.DPreDog.Sunset.CConcept
{
    internal class SunsetCConceptLeft : ModProjectile, ILocalizedModType
    {
        public new string LocalizationCategory => "Projectiles.NewWeapons.DPreDog";
        public override void SetStaticDefaults()
        {
            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 8;
            ProjectileID.Sets.TrailingMode[Projectile.type] = 2;
        }
        private Color chosenColor; // 用于存储随机选择的颜色
        private bool colorInitialized = false; // 是否已经初始化颜色

        public override bool PreDraw(ref Color lightColor)
        {
            // 初始化颜色（仅在弹幕生成时执行一次）
            if (!colorInitialized)
            {
                colorInitialized = true;
                Color[] colors = { Color.White, Color.Gold, Color.Black, Color.Red };
                chosenColor = Main.rand.Next(colors); // 随机选择颜色
            }

            // 绘制透明全息效果
            CalamityUtils.DrawAfterimagesCentered(
                Projectile,
                ProjectileID.Sets.TrailingMode[Projectile.type],
                chosenColor * 0.8f, // 透明度 80%
                1
            );

            return false; // 阻止默认绘制
        }

        public override void SetDefaults()
        {
            Projectile.width = Projectile.height = 32;
            Projectile.friendly = true;
            Projectile.hostile = false;
            Projectile.DamageType = DamageClass.Melee;
            Projectile.penetrate = 1;
            Projectile.timeLeft = 480;
            Projectile.light = 0.5f;
            Projectile.ignoreWater = true;
            Projectile.tileCollide = false;
            Projectile.extraUpdates = 1; // 额外更新次数
            Projectile.usesLocalNPCImmunity = true; // 弹幕使用本地无敌帧
            Projectile.localNPCHitCooldown = 30; // 无敌帧冷却时间为35帧
        }
        public override void AI()
        {
            // 添加不稳定的左右随机运动
            Projectile.velocity += new Vector2(Main.rand.NextFloat(-0.5f, 0.5f), 0f);

            // 获取屏幕右上角位置（血条位置）
            Vector2 healthBarPosition = Main.screenPosition + new Vector2(Main.screenWidth - 50, 50);

            // 调整方向并追踪目标位置
            Vector2 direction = (healthBarPosition - Projectile.Center).SafeNormalize(Vector2.Zero);
            Projectile.velocity = Vector2.Lerp(Projectile.velocity, direction * 10f, 0.1f); // 平滑调整速度和方向

            // 检测是否接触到目标位置
            if (Vector2.Distance(Projectile.Center, healthBarPosition) < 10f) // 接触检测
            {
                // 在原地释放特效并销毁自己
                OnReachHealthBar();
                Projectile.Kill();
            }
        }
        private void OnReachHealthBar()
        {
            // 在原地生成爆炸弹幕
            Projectile.NewProjectile(
                Projectile.GetSource_FromThis(),
                Projectile.Center,
                Vector2.Zero,
                ModContent.ProjectileType<SunsetCConceptLeftEXP>(), // 替换为对应弹幕类型
                Projectile.damage,
                Projectile.knockBack,
                Projectile.owner
            );

            // 生成爱心特效（Dust + 自定义形状）
            for (int i = 0; i < 36; i++) // 绘制圆形粒子
            {
                float angle = MathHelper.ToRadians(10 * i);
                Vector2 offset = angle.ToRotationVector2() * 20f;
                Vector2 position = Projectile.Center + offset;

                Dust heartDust = Dust.NewDustPerfect(
                    position,
                    DustID.RedMoss, // 红色爱心 Dust
                    Vector2.Zero,
                    150,
                    Color.Red,
                    1.5f
                );
                heartDust.noGravity = true;
            }
        }


        public override void OnKill(int timeLeft)
        {


        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            Main.player[Projectile.owner].AddBuff(ModContent.BuffType<SunsetCConceptPBuff>(), 300); // 5 秒
        }
    }
}