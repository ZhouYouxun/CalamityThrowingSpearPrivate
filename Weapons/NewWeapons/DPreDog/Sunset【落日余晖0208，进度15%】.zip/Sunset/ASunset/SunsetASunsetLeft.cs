﻿using CalamityMod.Buffs.DamageOverTime;
using CalamityMod.Particles;
using CalamityMod;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using CalamityMod.Projectiles.Typeless;

namespace CalamityThrowingSpear.Weapons.NewWeapons.DPreDog.Sunset.ASunset
{
    internal class SunsetASunsetLeft : ModProjectile, ILocalizedModType
    {
        public new string LocalizationCategory => "Projectiles.NewWeapons.DPreDog";
        public override void SetStaticDefaults()
        {
            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 8;
            ProjectileID.Sets.TrailingMode[Projectile.type] = 2;
        }

        public override bool PreDraw(ref Color lightColor)
        {
            CalamityUtils.DrawAfterimagesCentered(Projectile, ProjectileID.Sets.TrailingMode[Projectile.type], lightColor, 1);
            return false;
        }

        public override void SetDefaults()
        {
            Projectile.width = Projectile.height = 32;
            Projectile.friendly = true;
            Projectile.hostile = false;
            Projectile.DamageType = DamageClass.Melee;
            Projectile.penetrate = 1;
            Projectile.timeLeft = 480;
            Projectile.light = 0.5f;
            Projectile.ignoreWater = true;
            Projectile.tileCollide = false;
            Projectile.extraUpdates = 1; // 额外更新次数
            Projectile.usesLocalNPCImmunity = true; // 弹幕使用本地无敌帧
            Projectile.localNPCHitCooldown = 30; // 无敌帧冷却时间为35帧
        }
        public override void AI()
        {
            // 获取弹幕的运动方向
            Vector2 direction = -Projectile.velocity.SafeNormalize(Vector2.Zero);

            // 计算偏移量，使粒子呈现 DNA 双螺旋效果
            float phaseShift = (float)Math.Sin(Main.GameUpdateCount * 0.2f) * 8f; // 使粒子不断左右移动
            Vector2 leftOffset = direction.RotatedBy(MathHelper.PiOver2) * phaseShift; // 左侧偏移
            Vector2 rightOffset = direction.RotatedBy(-MathHelper.PiOver2) * phaseShift; // 右侧偏移

            // 生成左侧粒子（橙色）
            PointParticle leftSpark = new PointParticle(
                Projectile.Center + leftOffset,
                -Projectile.velocity * 0.5f,
                false,
                15,
                1.1f,
                Color.Orange
            );
            GeneralParticleHandler.SpawnParticle(leftSpark);

            // 生成右侧粒子（黄色）
            PointParticle rightSpark = new PointParticle(
                Projectile.Center + rightOffset,
                -Projectile.velocity * 0.5f,
                false,
                15,
                1.1f,
                Color.Yellow
            );
            GeneralParticleHandler.SpawnParticle(rightSpark);
        }



        public override void OnKill(int timeLeft)
        {


        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            Vector2 explosionPosition = Projectile.Center;

            // 生成爆炸粒子
            Particle explosion = new DetailedExplosion(
                explosionPosition,
                Vector2.Zero,
                Color.OrangeRed * 0.9f,
                Vector2.One,
                Main.rand.NextFloat(-5, 5),
                0f,
                0.28f,
                10
            );
            GeneralParticleHandler.SpawnParticle(explosion);

            // 额外生成多个小型爆炸粒子
            for (int i = 0; i < 5; i++)
            {
                Vector2 randomOffset = Main.rand.NextVector2Circular(16f, 16f);
                SparkleParticle impactParticle = new SparkleParticle(
                    explosionPosition + randomOffset,
                    Vector2.Zero,
                    Color.White,
                    Color.OrangeRed,
                    2.5f,
                    7,
                    0f,
                    2f
                );
                GeneralParticleHandler.SpawnParticle(impactParticle);
            }

            // 生成爆炸弹幕
            Projectile.NewProjectile(
                Projectile.GetSource_FromThis(),
                explosionPosition,
                Vector2.Zero,
                ModContent.ProjectileType<FuckYou>(),
                Projectile.damage,
                Projectile.knockBack,
                Projectile.owner
            );

            target.AddBuff(ModContent.BuffType<SunsetASunsetEDebuff>(), 300); // 300 帧 = 5 秒
        }
    }
}