﻿using CalamityMod;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using Microsoft.Xna.Framework;
using CalamityMod.Projectiles.Melee;
using CalamityMod.Particles;
using Terraria.Audio;

namespace CalamityThrowingSpear.Weapons.NewWeapons.DPreDog.Sunset.BForget
{
    internal class SunsetBForgetRightCut : ModProjectile, ILocalizedModType
    {
        public new string LocalizationCategory => "Projectiles.NewWeapons.DPreDog";
        public override void SetStaticDefaults()
        {
            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 8;
            ProjectileID.Sets.TrailingMode[Projectile.type] = 2;
        }

        public override bool PreDraw(ref Color lightColor)
        {
            CalamityUtils.DrawAfterimagesCentered(Projectile, ProjectileID.Sets.TrailingMode[Projectile.type], lightColor, 1);
            return false;
        }

        public override void SetDefaults()
        {
            Projectile.width = Projectile.height = 32;
            Projectile.friendly = true;
            Projectile.hostile = false;
            Projectile.DamageType = DamageClass.Melee;
            Projectile.penetrate = 1;
            Projectile.timeLeft = 480;
            Projectile.light = 0.5f;
            Projectile.ignoreWater = true;
            Projectile.tileCollide = false;
            Projectile.extraUpdates = 1; // 额外更新次数
            Projectile.usesLocalNPCImmunity = true; // 弹幕使用本地无敌帧
            Projectile.localNPCHitCooldown = 30; // 无敌帧冷却时间为35帧
        }
        private bool spawnedTentacles = false;

        public override void AI()
        {
            if (!spawnedTentacles) // 确保只在生成时触发一次
            {
                spawnedTentacles = true;

                // 生成 3 道触手（正前方、左 10°、右 10°）
                for (int i = -1; i <= 1; i++)
                {
                    Vector2 tentacleVelocity = Projectile.velocity.RotatedBy(MathHelper.ToRadians(i * 10f)) * 4f;
                    SpawnTentacle(tentacleVelocity);
                }

                // 额外随机 4 个角度释放触手
                for (int i = 0; i < 4; i++)
                {
                    Vector2 randomVelocity = Projectile.velocity.RotatedByRandom(MathHelper.ToRadians(45f)) * 4f;
                    SpawnTentacle(randomVelocity);
                }
            }

            // 直线飞行
            Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver4;
        }



        private void SpawnTentacle(Vector2 tentacleVelocity)
        {
            int damage = Projectile.damage / 2;
            float kb = Projectile.knockBack;

            float ai0 = Main.rand.NextFloat(0.01f, 0.08f) * (Main.rand.NextBool() ? -1f : 1f);
            float ai1 = Main.rand.NextFloat(0.01f, 0.08f) * (Main.rand.NextBool() ? -1f : 1f);

            if (Projectile.owner == Main.myPlayer)
                Projectile.NewProjectile(Projectile.GetSource_FromThis(), Projectile.Center, tentacleVelocity, ModContent.ProjectileType<VoidTentacle>(), damage, kb, Projectile.owner, ai0, ai1);
        }

        public override void OnKill(int timeLeft)
        {


        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            // 施加 Debuff 给敌人
            target.AddBuff(ModContent.BuffType<SunsetBForgetEDebuff>(), 300); // 5 秒

            // 施加 Buff 给玩家
            Main.player[Projectile.owner].AddBuff(ModContent.BuffType<SunsetBForgetPBuff>(), 300); // 5 秒

            Vector2 explosionPosition = target.Center;

            // 生成爆炸粒子
            for (int i = 0; i < 6; i++)
            {
                Vector2 randomOffset = Main.rand.NextVector2Circular(16f, 16f);
                SquishyLightParticle explosion = new SquishyLightParticle(
                    explosionPosition + randomOffset,
                    -Vector2.UnitY.RotatedByRandom(0.39f) * Main.rand.NextFloat(0.4f, 1.6f),
                    0.28f,
                    Color.Orange,
                    25
                );
                GeneralParticleHandler.SpawnParticle(explosion);
            }

            // 播放击中音效
            SoundEngine.PlaySound(SoundID.Item88, Projectile.position);
        }
    }
}