﻿using Terraria;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using Terraria.ID;
using System.Collections.Generic;
using CalamityMod;
using Terraria.Audio;

namespace CalamityThrowingSpear.Weapons.NewWeapons.DPreDog.Sunset.CConcept
{
    internal class SunsetCConceptLeftListener : ModProjectile, ILocalizedModType
    {
        public new string LocalizationCategory => "Projectiles.NewWeapons.DPreDog";
        public override string Texture => "CalamityMod/Projectiles/InvisibleProj"; // 透明贴图
        private List<int> subordinateProjectiles = new List<int>(); // 存储 4 个子弹幕的 ID

        public override void SetDefaults()
        {
            Projectile.width = 32;
            Projectile.height = 32;
            Projectile.friendly = true;
            Projectile.ignoreWater = true;
            Projectile.tileCollide = false;
            Projectile.penetrate = -1;
            Projectile.timeLeft = 600; // 10 秒
            Projectile.usesLocalNPCImmunity = true;
            Projectile.localNPCHitCooldown = 10;
        }

        public override void AI()
        {
            Player Owner = Main.player[Projectile.owner];

            if (Main.myPlayer == Projectile.owner)
            {
                Vector2 aimDirection = Owner.SafeDirectionTo(Main.MouseWorld);
                Projectile.velocity = Vector2.Lerp(Projectile.velocity, aimDirection, 0.1f);
            }

            Projectile.Center = Owner.Center + Projectile.velocity.SafeNormalize(Vector2.Zero) * (Projectile.width / 1);
            Owner.heldProj = Projectile.whoAmI;

            Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver4;
            Projectile.timeLeft = 300;
            Projectile.penetrate = -1;
            Projectile.tileCollide = false;

            // **管理玩家手臂方向**
            ManipulatePlayerArmPositions();

            //// **持续释放粒子**
            //if (Main.rand.NextBool(3)) // 约 1/3 概率生成
            //{
            //    int dustType = Main.rand.Next(new int[] { 87, 124, 175, 248 }); // 随机选取粒子颜色
            //    Dust dust = Dust.NewDustPerfect(Projectile.Center, dustType, Vector2.Zero, 100, Color.White, Main.rand.NextFloat(1f, 1.5f));
            //    dust.noGravity = true;
            //    dust.velocity *= 0.1f; // 让粒子缓慢运动
            //}

            // **检查是否需要补充子弹幕** [不再需要了]
            //MaintainSubordinateProjectiles();

            if (!Owner.channel)
            {
                Projectile.netUpdate = true;
                Projectile.Kill();
            }
        }
        //private void MaintainSubordinateProjectiles()
        //{
        //    // 统计当前存活的 `SunsetCConceptLeft`
        //    subordinateProjectiles.RemoveAll(id => !Main.projectile[id].active || Main.projectile[id].type != ModContent.ProjectileType<SunsetCConceptLeft>());

        //    // **如果数量少于 4，则依次补充**
        //    if (subordinateProjectiles.Count < 4)
        //    {
        //        Player Owner = Main.player[Projectile.owner];
        //        Vector2[] spawnOffsets = { new Vector2(-5 * 16, 0), new Vector2(5 * 16, 0), new Vector2(0, -5 * 16), new Vector2(0, 5 * 16) };

        //        foreach (Vector2 offset in spawnOffsets)
        //        {
        //            if (subordinateProjectiles.Count >= 4) // **确保不会超出 4 个**
        //                break;

        //            Vector2 spawnPos = Owner.Center + offset;
        //            int projID = Projectile.NewProjectile(Projectile.GetSource_FromThis(), spawnPos, Vector2.Zero, ModContent.ProjectileType<SunsetCConceptLeft>(), Projectile.damage, Projectile.knockBack, Projectile.owner);
        //            subordinateProjectiles.Add(projID);
        //        }
        //    }
        //}

        public override void OnSpawn(Terraria.DataStructures.IEntitySource source)
        {
            base.OnSpawn(source);


            Player Owner = Main.player[Projectile.owner];

            // **4 个不同的 `SunsetCConceptLeft` 变体**
            (Vector2 offset, int projType)[] spawnData = {
                (new Vector2(-5 * 16, -5 * 16), ModContent.ProjectileType<SunsetCConceptLeftBlack>()),  // 左上角
                (new Vector2(5 * 16, -5 * 16), ModContent.ProjectileType<SunsetCConceptLeftBlue>()),   // 右上角
                (new Vector2(-5 * 16, 5 * 16), ModContent.ProjectileType<SunsetCConceptLeftRed>()),    // 左下角
                (new Vector2(5 * 16, 5 * 16), ModContent.ProjectileType<SunsetCConceptLeftYellow>())   // 右下角
            };

            // **依次生成 4 种 `SunsetCConceptLeft`**
            foreach (var data in spawnData)
            {
                Vector2 spawnPos = Owner.Center + data.offset;
                int projID = Projectile.NewProjectile(Projectile.GetSource_FromThis(), spawnPos, Vector2.Zero, data.projType, Projectile.damage, Projectile.knockBack, Projectile.owner);
                if (IsValidProjectile(projID))
                {
                    subordinateProjectiles.Add(projID);
                }
                subordinateProjectiles.Add(projID);
            }
        }
        private bool IsValidProjectile(int projID)
        {
            return projID >= 0 && Main.projectile[projID].active;
        }


        public override void OnKill(int timeLeft)
        {
            // **删除所有 4 种 `SunsetCConceptLeft`**
            foreach (int projID in subordinateProjectiles)
            {
                if (Main.projectile[projID].active && (
                    Main.projectile[projID].type == ModContent.ProjectileType<SunsetCConceptLeftBlack>() ||
                    Main.projectile[projID].type == ModContent.ProjectileType<SunsetCConceptLeftBlue>() ||
                    Main.projectile[projID].type == ModContent.ProjectileType<SunsetCConceptLeftRed>() ||
                    Main.projectile[projID].type == ModContent.ProjectileType<SunsetCConceptLeftYellow>()))
                {
                    Main.projectile[projID].Kill();
                }
            }

            // **播放消失音效**
            SoundEngine.PlaySound(SoundID.Item117, Projectile.Center);
        }

        public void ManipulatePlayerArmPositions()
        {
            Player Owner = Main.player[Projectile.owner];

            // **让玩家的手臂方向始终朝向长枪的方向**
            Owner.ChangeDir(Projectile.direction);
            Owner.heldProj = Projectile.whoAmI;

            // **计算双臂应当指向的角度，使其平行向前**
            float armRotation = Projectile.velocity.ToRotation() - MathHelper.PiOver2;

            // **设置玩家前臂（主手）和后臂（副手）的角度，使其平行前伸**
            Owner.SetCompositeArmFront(true, Player.CompositeArmStretchAmount.Full, armRotation);
            Owner.SetCompositeArmBack(true, Player.CompositeArmStretchAmount.Full, armRotation);
        }
    }
}
